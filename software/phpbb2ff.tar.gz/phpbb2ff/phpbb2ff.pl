#!/usr/bin/env perl

#
#                    PHPBB2FF - PHP BB2 Feed Filter
#
#        (c) 2004 Alexandre Erwin Ittner <aittner@netuno.com.br>
#                  http://users.netuno.com.br/aittner/
#
#
#   Este programa l� os t�picos de qualquer f�rum baseado no  PHPBB2
#   e os  retorna em um formato  RDF  padronizado,  para exibi��o em
#   qualquer  leitor de  feeds que suporte leitura a partir da sa�da
#   de comandos.
#
#   ATEN��O:  Vale lembrar que esse script l� os dados a  partir  do
#   HTML existente no f�rum!  Qualquer mudan�a no site provavelmente
#   o far� parar de funcionar!
#
#
#                            LICEN�A DE USO
#
#   Este  programa � um  software  livre  que  pode  ser  copiado  e
#   distribu�do nos termos da Licen�a P�blica Geral GNU (GNU General
#   Public License - GPL) vers�o 2 da licen�a ou,  a  seu  crit�rio,
#   qualquer   vers�o  posterior.   Este   programa  foi  criado  na
#   expectativa  de  ser  �til,  por�m  N�O POSSUI NENHUMA GARANTIA,
#   EXPRESSA, IMPL�CITA  OU  DE  ATENDIMENTO  A  ALGUMA  DETERMINADA
#   FINALIDADE.  Para  maiores informa��es consulte o texto completo
#   da  Licen�a P�blica Geral  GNU  no arquivo  COPYING  distribu�do
#   juntamente com este programa.
#
#
# $Id: phpbb2ff.pl,v 1.16 2004/11/14 21:25:43 dermeister Exp $
#

if($#ARGV != 1)
{
    print "Usage: phpbb2ff.pl <url> <n�mero>\n";
    exit(1);
}

# Revis�o do CVS. Deixe que ele cuide disso!
my $cvsid = '$Revision: 1.16 $';
my $cvsrev = "0.0";
if($cvsid =~ /\$Revision: *([0-9.]*)/i)
{
    $cvsrev = $1
}

my $urlbase = @ARGV[0];
my $number = @ARGV[1];
my $urllist = "$urlbase/viewforum.php?f=$number";

my $dados = `wget -q -O - $urllist`;
#my $dados = `cat teste.html`;
$dados =~ s/\n/ /gi;
$dados =~ s/\t/ /g;

$dados =~ s/<style[^>]*>[^<]*<\/style>//gi;
$dados =~ s/<script[^>]*>[^<]*<\/script>//gi;
$dados =~ s/<(base)?font [^>]*>//gi;
$dados =~ s/<\/font>//gi;
$dados =~ s/<img[^>]*>//gi;
$dados =~ s/<!--[^<>]*-->//gi;

$dados =~ s/<table *[^>]*>/<table>/gi;
$dados =~ s/<th *[^>]*>/<th>/gi;
$dados =~ s/<tr *[^>]*>/<tr>/gi;
$dados =~ s/<td *[^>]*>/<td>/gi;
$dados =~ s/<\/?span[^>]*\/?>//gi;
$dados =~ s/<div[^>]*>/<div>/gi;

$dados =~ s/&nbsp;/ /gi;
while($dados =~ /  /)
{
    $dados =~ s/  / /g;
}

$dados =~ s/> *</></gi;
$dados =~ s/< */</gi;
$dados =~ s/ *>/>/gi;

# Obt�m o t�tulo da p�gina.
my $title = "Sem t�tulo";
if ($dados =~ /<title>([^>]+)<\/title>/i)
{
    $title = $1;
}

# Tenta detectar o charset utilizado. Perigo: pode criar XML inv�lido!!
my $charset = "iso-8859-1";
if ($dados =~ /<meta [^>]*; *charset=([^"]+)"/i)
{
    $charset = $1;
}


print "<?xml version=\"1.0\" encoding=\"$charset\"?>\n";
print "<rdf:RDF\n";
print "  xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n";
print "  xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n";
print "  xmlns=\"http://purl.org/rss/1.0/\">\n";
print " <channel rdf:about=\"$urllist\">\n";
print "  <title>$title</title>\n";
print "  <link>$urllist</link>\n";
print "  <description>";
print " Feed extra�do automaticamente do \"$title\" pelo phpbb2ff.pl vers�o";
print " $cvsrev\. Lembre-se que mudan�as no f�rum podem fazer esse script";
print " parar de funcionar a qualquer momento. Em caso de qualquer problema,";
print " tente primeiro obter uma vers�o mais atualizada deste script em";
print " http://users.netuno.com.br/aittner/data/phpbb2ff.tar.gz\n";
print "  </description>\n";
print "  <items>\n";
print "   <rdf:Seq>\n";


# Vamos dividir a lista a cada "<tr>" e come�ar a procurar por t�picos.
my @mlist = split(/<tr>/i, $dados);
my $i = 0;
my @itemlist;
my $lastitem = 0;
while($i < $#mlist)
{
    my $tmp = @mlist[$i];

    # Formato de um t�pico do f�rum. Note que grande parte dos elementos
    # in�teis da tabela (imagens, etc.)  j� foram removidos.
    #
    # <td></td>
    # <td>
    #   <a href="viewtopic.php?t=38335" class="topictitle">Linux</a>
    #   <br />
    #   [ Ir � p�gina: <a href="viewtopic.php?t=38335&amp;start=0">1</a>,
    #    <a href="viewtopic.php?t=38335&amp;start=20">2</a> ]
    # </td>
    # <td>34</td>
    # <td><a href="profile.php?mode=viewprofile&amp;u=9981">DeMoN`WiZ</a></td>
    # <td>253</td>
    # <td>
    #   Dom Set 12, 2004 8:07 pm
    #  <br /><a href="profile.php?mode=viewprofile&amp;u=154">Sercelda</a>
    #  <a href="viewtopic.php?p=1050516#1050516"></a>
    # </td>
    # </tr>

    # retira a lista de p�ginas, se existir.
    # <br> [ xxxxxx ] </td>
    $tmp =~ s/<br *\/?> *\[[^\]]* *\] *<\/td>/<\/td>/gi;
    
    # retira o primeiro <td></td> (que era reservado para o �cone do t�pico)
    $tmp =~ s/^<td><\/td>//;

    # e o </tr> que sobrou ao dividir a tabela.
    $tmp =~ s/<\/tr>//g;

    # Se a "coisa" se parecer com a estrutura abaixo, � um t�pico!
    # Lembrando que a �ltima parte � a �ltima resposta para o t�pico, que n�o
    # precisa, necessariamente, existir. A id�ia � usar os links para 
    # evitar falsos positivos.
    #
    # <td><a href="viewtopic.php?t=38335" class="topictitle">Linux</a></td>
    # <td>34</td>
    # <td><a href="profile.php?mode=viewprofile&amp;u=9981">DeMoN`WiZ</a></td>
    # <td>253</td>
    # <td>
    #  Dom Set 12, 2004 8:07 pm
    #   <br /><a href="profile.php?mode=viewprofile&amp;u=154">Sercelda</a>
    #   <a href="viewtopic.php?p=1050516#1050516"></a>
    # </td>

    @line = split(/<\/td><td>/i, $tmp);
    if(@line[0] =~ /href *= *"(viewtopic\.php[^"]+)"[^>]*>([^<]*)<\/a>/i)
    {
        $topurl = $1;   # Url do t�pico
        $toptit = $2;   # T�tulo do t�pico

        #Essa regex s� funciona no Perl -- thx Aur�lio, http://guia-er.sourceforge.net/
        $toptit =~ s/&(?![a-z]+;)/&amp;/gi;
       
        if(@line[1] =~ /([0-9]+)/)
        {
            $topres = $1;   # N�mero de respostas do t�pico
            if(@line[2] =~ /href *= *"(profile\.php[^"]*)"[^>]*>([^<]*)<\/a>/i)
            {
                $auturl = $1;   # Url do profile do autor do t�pico
                $topaut = $2;   # Autor do t�pico
                if(@line[3] =~ /([0-9]+)/)
                {
                    $toplei = $1;   # N�mero de leituras

                    # Tenta extrair a data e autor da �ltima resposta (que n�o
                    # precisa existir)

                    $lresp = @line[4];
                    # Sobrou um </td>
                    $lresp =~ s/<\/td>//;

                    $data_ur = "";
                    $nome_ur = "";
                    $url_ur = "";
                    #print "<!-- $lresp -->\n";
                    if($lresp =~ /<br *\/?>/i)
                    {
                        @ret_ur = split(/<br *\/?>/i, $lresp);
                        $data_ur = @ret_ur[0];
                        $texto_ur = @ret_ur[1];
                        if($texto_ur =~ /href *= *"profile\.php[^>]*>([^<]*)<\/a>/i)
                        {
                            $nome_ur = $1;
                        }
                        if($texto_ur =~ /href *= *"(viewtopic\.php[^"]+)"[^>]*>/i)
                        {
                            $url_ur = $1;
                        }
                    }

                    # Retira informa��es de sess�o das urls.
                    $topurl =~ s/&amp;sid=[0-9a-f]*//gi;
                    $auturl =~ s/&amp;sid=[0-9a-f]*//gi;
                    $url_ur =~ s/&amp;sid=[0-9a-f]*//gi;
                    
                    # Truque sujo: a url � o ressource do feed e ressources
                    # diferentes s�o exibidos como itens diferentes pelo
                    # leitor de feeds. Ao colocar o n�mero de respostas do
                    # t�pico no ressource, for�amos o leitor a reexibir 
                    # os t�picos que foram respondidos desde a �ltima letura.
                    $abstopurl = "$urlbase/$topurl&amp;php2ffres=$topres";

                    $text = " <item rdf:about=\"$abstopurl\">\n"
                           ."  <title>$toptit [$topaut, $topres]</title>\n"
                           ."  <link>$abstopurl</link>\n"
                           ."  <description>\n"
                           ."   T�pico: &lt;a href=\"$abstopurl\"&gt; $toptit &lt;/a&gt; &lt;br /&gt;\n"
                           ."   Autor: &lt;a href=\"$urlbase/$auturl\"&gt; $topaut &lt;/a&gt; &lt;br /&gt;\n"
                           ."   Leituras: $toplei &lt;br /&gt;\n"
                           ."   Respostas:$topres &lt;br /&gt;\n";

                    unless($data_ur eq "")
                    {
                        $text .= "   �ltima resposta: &lt;a href=\"$urlbase/$url_ur\"&gt; $data_ur (por $nome_ur) &lt;/a&gt; &lt;br/&gt;\n";
                    }

                    $text .= "  </description>\n"
                            ."  <dc:subject>$toptit</dc:subject>\n"
                            ."  <dc:creator>$topaut</dc:creator>\n"
                            ." </item>\n";
                   
                    @itemlist[$lastitem] = $text;
                    $lastitem++;
                    
                    print "    <rdf:li rdf:resource=\"$abstopurl\" />\n";
                }
            }
        }
    }   

    $i += 1;
}

print "   </rdf:Seq>\n";
print "  </items>\n";
print " </channel>\n";

foreach $curitem (@itemlist)
{
    print $curitem;
}

print "</rdf:RDF>\n";



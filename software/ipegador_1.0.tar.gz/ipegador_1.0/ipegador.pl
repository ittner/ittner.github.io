#!/usr/local/bin/perl 
################################################################
#
# 
#            I  P  E  G  A  D  O  R   1 . 0
#
#         (c) 2002 ALEXANDRE ERWIN ITTNER 
#         aittner@netuno.com.br
#         http://users.netuno.com.br/aittner/
#
#
# Este  programa � um software de livre distribui��o, que 
# pode ser copiado e distribu�do sob os termos da Licen�a 
# P�blica Geral GNU  ( GNU General Public License - GPL ) 
# vers�o  2,   conforme   publicada  pela  Free  Software 
# Foundation.  Este programa � distribu�do na expectativa 
# de  ser  �til  aos  seus usu�rios, por�m N�O H� NENHUMA 
# GARANTIA,  EXPL�CITA  OU  IMPL�CITA,  COMERCIAL  OU  DE 
# ATENDIMENTO  A UMA  DETERMINADA FINALIDADE.  Consulte a 
# Licen�a  P�blica  Geral GNU (GNU General Public License
# - GPL) para maiores detalhes. 
#
#
################################################################
# Vari�veis de configura��o
################################################################

$arquivo_log = "log_ips.txt";	# O nome do arquivo para LOG
$arquivo_imagem = "imagem.gif";	# Imagem para exibir na p�gina
$fuso_horario = "-3";           # Fuso hor�rio em rela��o ao GMT,
                                # isto � bastante �til quando a 
                                # sua p�gina e o script est�o em
                                # servidores de zonas diferentes.

################################################################

$ip_visitante = $ENV{'REMOTE_ADDR'};
if($ip_visitante eq "")
	{
	$ip_visitante = "[DESCONHECIDO]";
	}
$referer = $ENV{'HTTP_REFERER'};
if($referer eq "")
	{
	$referer = "[DESCONHECIDO]";
	}
$navegador_visitante = $ENV{'HTTP_USER_AGENT'};
if($navegador_visitante eq "")
	{
	$navegador_visitante = "[DESCONHECIDO]";
	}
$fuso_horario_segundos = $fuso_horario * 3600;
$hora_convertida = time();
$hora_convertida = $hora_convertida + $fuso_horario_segundos;
($segundos,$minutos,$horas,$dia,$mes,$ano,$diadasemana,$diadoano,$ehbissexto) = gmtime($hora_convertida);
$ano = $ano + 1900;
$mes++;
if ($mes < 10 )
	{
	$mes = "0$mes";
	}
if ($dia < 10)
	{
	$dia = "0$dia";
	}
$data = "$dia/$mes/$ano";
if ($horas < 10 )
	{
	$horas = "0$horas";
	}
if ($minutos < 10 )
	{
	$minutos = "0$minutos";
	}
if ($segundos < 10 )
	{
	$segundos = "0$segundos";
	}
$hora = "$horas:$minutos:$segundos";
open(arq_log,">>$arquivo_log");
print arq_log "$ip_visitante : $data as $hora ($fuso_horario GMT) : $referer : $navegador_visitante\n";
close(arq_log);

print "Location: $arquivo_imagem\n\n";

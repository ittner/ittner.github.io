#!/usr/bin/env python
# -*- coding: utf-8 -*-

u"""
           Script para extrair feeds RSS de fóruns vBulletin
       (c) 2005 Alexandre Erwin Ittner <alexandre@ittner.com.br>
                      http://www.ittner.com.br/

                            LICENÇA DE USO

   Este  programa é um  software  livre  que  pode  ser  copiado  e
   distribuído nos termos da Licença Pública Geral GNU (GNU General
   Public License - GPL) versão 2 da licença ou,  a  seu  critério,
   qualquer   versão  posterior.   Este   programa  foi  criado  na
   expectativa  de  ser  útil,  porém  NÃO POSSUI NENHUMA GARANTIA,
   EXPRESSA, IMPLÍCITA  OU  DE  ATENDIMENTO  A  ALGUMA  DETERMINADA
   FINALIDADE.  Para  maiores informações consulte o texto completo
   da  Licença Pública Geral  GNU  no arquivo  COPYING  distribuído
   juntamente com este programa.

"""


import sys
import time, datetime
import sre
import urllib2
from HTMLParser import HTMLParser, HTMLParseError
from PyRSS2Gen import RSS2, RSSItem


_version = "0.10"



def findDateTime(datestr):
    """
    Tenta obter uma data no formato DD-MM-AAAA HH:MM de uma string e
    a retorna como um 'datatime', se a busca for bem sucedida. Caso
    contrário, retorna None.
    """

    rx = "([0-9]{2})[./-]([0-9]{2})[./-]([0-9]{4}) *([0-9]{2})[:-]([0-9]{2})"
    dt = sre.findall(rx, datestr)
    if dt[0:]:
        d = dt[0]
        return datetime.datetime(int(d[2]), int(d[1]), int(d[0]),
            int(d[3]), int(d[4]))
    return None



def removeSessionID(str):
    """
    Remove a session-id da URL. Isso garante que as urls dos tópicos sejam
    sempre únicas, permitindo ao newsreader manter o controle sobre os
    tópicos já lidos.
    """
    return sre.sub("s=[0-9a-f]+", "vb2rss=1", str)



class VBulletinParser(HTMLParser):
    """
    Parser para o HTML do vBulletin. Parsers HTML e salsichas: você não
    os consumiria se soubesse como são feitos.
    """

    def __init__(self):
        self.reset()
        self._state = "wtitle"
        self._items = []
        self._forumtitle = None
        self._pdescr = None
        self._purl = None
        self._ptitle = None
        self._pdtstr = None
        self._pauthor = None
        self._pauthorurl = None
        self._plastrepurl = None
        self._preplies = None

    # wtitle -> dtitle -> wdescr -> wurl -> dptitle -> wdate -> ddate ->
    # -> wtime -> dtime -> wauth -> dauth -> wlasrrep -> wreplies ->
    # -> dreplies -> wdescr

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        #print("start: " + tag + " " + self._state)
        #print(attrs)

        if self._state == "wtitle" and tag == "title":
            self._state = "dtitle"

        elif self._state == "wdescr" and tag == "td" and \
            attrs.has_key("class") and attrs.has_key("title"):
            if attrs["class"] == "alt1Active":
                self._pdescr = attrs["title"]
                self._state = "wurl"

        elif self._state == "wurl" and tag == "a" and attrs.has_key("href"):
            if attrs["href"].startswith("showthread.php"):
                self._purl = removeSessionID(attrs["href"])
                self._state = "dptitle"

        elif self._state == "wdate" and tag == "div" and \
            attrs.has_key("class") and attrs.has_key("style"):
            if attrs["class"] == "smallfont":
                self._state = "ddate"

        elif self._state == "wtime" and tag == "span" and \
            attrs.has_key("class"):
            if attrs["class"] == "time":
                self._state = "dtime"

        elif self._state == "wauth" and tag == "a" and attrs.has_key("href"):
            if attrs["href"].startswith("member.php"):
                self._pauthorurl = removeSessionID(attrs["href"])
                self._state = "dauth"

        elif self._state == "wlastrep" and tag == "a" and \
            attrs.has_key("href"):
            if attrs["href"].startswith("showthread.php"):
                self._plastrepurl = removeSessionID(attrs["href"])
                self._state = "wreplies"

        elif self._state == "wreplies" and tag == "td" and \
            attrs.has_key("class"):
            if attrs["class"] == "alt1":
                self._state = "dreplies"


    def handle_data(self, data):
        #print("data: " + self._state)

        if self._state == "dtitle":
            self._forumtitle = data
            self._state = "wdescr"

        elif self._state == "dptitle":
            self._ptitle = data
            self._state = "wdate"

        elif self._state == "ddate":
            self._pdtstr = data
            self._state = "wtime"

        elif self._state == "dtime":
            self._pdtstr += " " + data
            self._state = "wauth"

        elif self._state == "dauth":
            self._pauthor = data
            self._state = "wlastrep"

        elif self._state == "dreplies":
            self._preplies = data
            self._items.append({
                "pdescr"        : self._pdescr,
                "purl"          : self._purl + "&rpls=" + self._preplies,
                "ptitle"        : self._ptitle,
                "pdtstr"        : self._pdtstr,
                "pauthor"       : self._pauthor,
                "pauthorurl"    : self._pauthorurl,
                "plastrepurl"   : self._plastrepurl,
                "preplies"      : self._preplies
                })
            self._state = "wdescr"


    def get_items(self):
        return self._items

    def get_title(self):
        return self._forumtitle



def parseOne(baseurl, forum, fname=None):
    """
    Obtém os feeds de um fórum. 'baseurl' é a Url do diretório onde o
    fórum é acessado e 'forum' é o número do fórum. Por exemplo, para o
    fórum http://forum.valinor.com.br/forumdisplay.php?f=37 temos

    baseurl = http://forum.valinor.com.br/
    forum   = 37

    'fname' é o nome de um arquivo para onde os dados serão escritos,
    ou None para enviá-los para stdout.
    """

    url = baseurl + "forumdisplay.php?f=" + forum
    reader = urllib2.urlopen(url)
    data = reader.read()
#    data = open("teste.html", "r").read()

    #print(data)
    parser = VBulletinParser()
    parser.feed(data)
    parser.close()

    tma = time.gmtime()
    tm = datetime.datetime(tma[0], tma[1], tma[2], tma[3], tma[4], tma[5])

    title = parser.get_title()
    rss = RSS2(
        title = title,
        link = url,
        description = title + "  (" + url + ")<br/>" + \
            u" Feed gerado com o vb2rss.py versão " + _version,
        lastBuildDate = tm
    )

    for itm in parser.get_items():
        #print(itm)
        descr = itm["pdescr"] + "<br/><br/>" +                          \
            u"Última resposta por: <a href=\"" + baseurl +               \
            itm["pauthorurl"] + "\">" + itm["pauthor"] + "</a><br>" +   \
            u"Última resposta em: <a href=\"" + baseurl +                \
            itm["plastrepurl"] + "\">" + itm["pdtstr"] + "</a><br>"     \
            u"Total de respostas: " + itm["preplies"] + "<br>"

        rss.items.append(RSSItem(
            title = itm["ptitle"],
            link =  baseurl + itm["purl"],
            description = descr,
            pubDate = findDateTime(itm["pdtstr"])
        ))

    if fname != None:
        fp = open(fname, "w")
    else:
        fp = sys.stdout
    rss.write_xml(fp)



if __name__ == '__main__':
    try:
        if sys.argv[3:]:
            fname = sys.argv[3]
        else:
            fname = None
        parseOne(sys.argv[1], sys.argv[2], fname)
    except IndexError:
        print u"Erro: Argumentos inválidos."
    except ValueError:
        print u"Erro: URL inválida."
    except urllib2.URLError:
        print u"Erro: Endereço inacessível."


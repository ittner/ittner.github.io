/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */


#include "node.h"



TSombrasNode *SombrasNodeNew(char *id)
    {
    TSombrasNode *node;
    node = (TSombrasNode *) malloc(sizeof(TSombrasNode));
    if(node == NULL)
        return NULL;    /* erro */

    node->id = (char *) malloc((strlen(id)+1) * sizeof(char));
    if(node->id == NULL)
        return NULL;    /* erro */

    strcpy(node->id, id);

    node->title = (char *) malloc(sizeof(char));
    if(node->title == NULL)
        return NULL;    /* erro */

    node->title[0] = '\0';

    node->desc = (char *) malloc(sizeof(char));
    if(node->desc == NULL)
        return NULL;    /* erro */

    node->desc[0] = '\0';

    node->exits = (TSombrasExit **) malloc(sizeof(TSombrasExit*));
    if(node->exits == NULL)
        return NULL;    /* erro */

    node->numexits = 0;

    return node;
    }






int SombrasNodeSetTitle(TSombrasNode *node, char *title)
    {
    node->title = (char *) realloc(node->title, (strlen(title)+1) * sizeof(char));
    if(node->title == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    strcpy(node->title, title);
    return SOMBRAS_OK;
    }





int SombrasNodeSetDesc(TSombrasNode *node, char *desc)
    {
    node->desc = (char *) realloc(node->desc, (strlen(desc)+1) * sizeof(char));
    if(node->desc == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    strcpy(node->desc, desc);
    return SOMBRAS_OK;
    }





int SombrasNodeAppendDesc(TSombrasNode *node, char *desc)
    {
    node->desc = (char *) realloc(node->desc,
                (strlen(node->desc) + strlen(desc) + 1) * sizeof(char));

    if(node->desc == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    strcat(node->desc, desc);
    return SOMBRAS_OK;
    }





int SombrasNodeAddExit(TSombrasNode *node, char *node_id,  char *node_desc)
    {
    TSombrasExit *temp_exit;

    /* vamos inicialmente copiar os dados desta saida para um
       local na memoria, depois colocaremos um ponteiro na 
       para este local na estrutura principal do no 
     */

    temp_exit = (TSombrasExit *) malloc(sizeof(TSombrasExit));
    if(temp_exit == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    temp_exit->id = (char *) malloc((strlen(node_id)+1)*sizeof(char));
    if(temp_exit->id == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    strcpy(temp_exit->id, node_id);


    temp_exit->desc = (char *) malloc((strlen(node_desc)+1)*sizeof(char));
    if(temp_exit->desc == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    strcpy(temp_exit->desc, node_desc);


    /* Agora  devemos adicionar um ponteiro para esta saida 
       na estrutura do n�, para que possa ser localizada depois
     */

    node->exits = (TSombrasExit **) realloc(node->exits, 
                        (node->numexits+1)*sizeof(TSombrasExit*));
    if(node->exits == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    node->exits[node->numexits] = temp_exit;
    node->numexits++;

    return SOMBRAS_OK;
    }




void SombrasNodeDestroy(TSombrasNode *node)
    {
    free(node->id);
    free(node->desc);
    free(node->title);

    while(node->numexits > 0)
        {
        free((node->exits[node->numexits-1])->desc);
        free((node->exits[node->numexits-1])->id);
        free(node->exits[node->numexits-1]);
        node->numexits--;
        }

    free(node->exits);
    }




char *SombrasNodeGetID(TSombrasNode *node)
    {
    return node->id;
    }




char *SombrasNodeGetTitle(TSombrasNode *node)
    {
    return node->title;
    }




char *SombrasNodeGetDesc(TSombrasNode *node)
    {
    return node->desc;
    }




int SombrasNodeGetNumExits(TSombrasNode *node)
    {
    return node->numexits;
    }


    

char *SombrasNodeGetExitID(TSombrasNode *node, int exit)
    {
    if(exit < 0 || exit >= SombrasNodeGetNumExits(node))
        return NULL; /* error */

    return (node->exits[exit])->id;
    }




char *SombrasNodeGetExitDesc(TSombrasNode *node, int exit)
    {
    if(exit < 0 || exit >= SombrasNodeGetNumExits(node))
        return NULL; /* error */

    return (node->exits[exit])->desc;
    }

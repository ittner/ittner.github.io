/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sombras.h"
#include "node.h"
#include "utils.h"


#ifndef SOMBRAS_NODELIST_H
#define SOMBRAS_NODELIST_H

typedef struct
    {
    TSombrasNode **nodes;
    unsigned int numnodes;
    } TSombrasNodeList;



TSombrasNodeList *SombrasNodeListNew(void);
void SombrasNodeListDestroy(TSombrasNodeList *nodelist);

int SombrasNodeListAddNode(TSombrasNodeList *nodelist, TSombrasNode *node);
unsigned int SombrasNodeListGetSize(TSombrasNodeList *nodelist);
TSombrasNode *SombrasNodeListGetNode(TSombrasNodeList *nodelist, char *id);

TSombrasNodeList *SombrasNodeListNewFromFile(char *filename);

int SombrasNodeListDebug(TSombrasNodeList *nodelist);


#endif

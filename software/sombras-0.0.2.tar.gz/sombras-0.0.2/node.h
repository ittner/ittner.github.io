/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sombras.h"

#ifndef SOMBRAS_NODE_H
#define SOMBRAS_NODE_H



typedef struct
    {
    char *id;
    char *desc;
    } TSombrasExit;



typedef struct
    {
    char *id;
    char *title;
    char *desc;
    int numexits;
    TSombrasExit **exits;
    } TSombrasNode;





TSombrasNode *SombrasNodeNew(char *id);
void SombrasNodeDestroy(TSombrasNode *node);

int SombrasNodeSetTitle(TSombrasNode *node, char *title);
int SombrasNodeSetDesc(TSombrasNode *node, char *desc);
int SombrasNodeAppendDesc(TSombrasNode *node, char *desc);
int SombrasNodeAddExit(TSombrasNode *node, char *node_id,  char *node_desc);

char *SombrasNodeGetID(TSombrasNode *node);
char *SombrasNodeGetTitle(TSombrasNode *node);
char *SombrasNodeGetDesc(TSombrasNode *node);

int SombrasNodeGetNumExits(TSombrasNode *node);
char *SombrasNodeGetExitID(TSombrasNode *node, int exit);
char *SombrasNodeGetExitDesc(TSombrasNode *node, int exit);

#endif


/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */



#include "nodelist.h"


TSombrasNodeList *SombrasNodeListNew(void)
    {
    TSombrasNodeList *nodelist;

    nodelist = (TSombrasNodeList *) malloc(sizeof(TSombrasNodeList));
    if(nodelist == NULL)
        return NULL;

    nodelist->nodes = (TSombrasNode **) malloc(sizeof(TSombrasNode*));
    if(nodelist->nodes == NULL)
        {
        free(nodelist);
        return NULL;
        }

    nodelist->numnodes = 0;
    return nodelist;
    }




    
void SombrasNodeListDestroy(TSombrasNodeList *nodelist)
    {
    while(nodelist->numnodes > 0)
        {
        SombrasNodeDestroy(nodelist->nodes[nodelist->numnodes-1]);
        nodelist->numnodes--;
        }
    free(nodelist->nodes);
    free(nodelist);
    }


        


int SombrasNodeListAddNode(TSombrasNodeList *nodelist, TSombrasNode *node)
    {
    if(SombrasNodeListGetNode(nodelist, SombrasNodeGetID(node)) != NULL)
        return SOMBRAS_ERROR_NODE_ALREADY_EXISTS;

    nodelist->nodes = (TSombrasNode **) realloc(nodelist->nodes,
                    (nodelist->numnodes+1)*sizeof(TSombrasNode*));
    if(nodelist->nodes == NULL)
        return SOMBRAS_ERROR_NO_MEMORY;

    nodelist->nodes[nodelist->numnodes] = node;
    nodelist->numnodes++;
    return SOMBRAS_OK;
    }





unsigned int SombrasNodeListGetSize(TSombrasNodeList *nodelist)
    {
    return nodelist->numnodes;
    }




TSombrasNode *SombrasNodeListGetNode(TSombrasNodeList *nodelist, char *id)
    {
    unsigned int temp = 0;
    while(temp < nodelist->numnodes)
        {
        if(!strcmp(id, SombrasNodeGetID(nodelist->nodes[temp])))
            return nodelist->nodes[temp];
        temp++;
        }
    return NULL; /* node not found */
    }





TSombrasNodeList *SombrasNodeListNewFromFile(char *filename)
    {
    FILE *arq;
    char *buffer;
    char *token;
    char *tempstr;
    int line = 0;
    unsigned long bufsize;
    TSombrasNode *node;
    TSombrasNodeList *nodelist;



    nodelist = SombrasNodeListNew();
    if(nodelist == NULL)
        return NULL;  /* ERROR */

    arq = fopen(filename, "rt");
    if(arq == NULL)
        {
        SombrasNodeListDestroy(nodelist);
        return NULL;  /* ERROR */
        }

    fseek(arq, 0, SEEK_END);
    bufsize = ftell(arq);
    fseek(arq, 0, SEEK_SET);

    buffer = (char *) malloc((bufsize+1)*sizeof(char));
    if(buffer == NULL)
        {
        SombrasNodeListDestroy(nodelist);
        fclose(arq);
        return NULL;  /* error */
        }



    line = 0;
    node = NULL;  /* n� nao est� aberto */
    while(fgets(buffer, bufsize, arq))
        {
        line++;   /* incrementar isso sempre que ler uma linha!! */ 
        SombrasStrTrim(buffer);


        token = SombrasGetToken(buffer, ".node");
        if(token)
            {
            SombrasStrTrim(token);
            if(node != NULL)
                {
                /* o n� anterior  n�o foi fechado com .end. fecha arora e 
                   deixa um warning
                */
                SombrasWarning("%s: line %i: Attempt to create node '%s' inside another! "
                                "('.end' expected)", filename, line, token);
                if(SombrasNodeListAddNode(nodelist, node) == SOMBRAS_ERROR_NODE_ALREADY_EXISTS)
                    {
                    SombrasWarning("%s: line %i: .end: Node '%s' ('%s') already defined",
                                    filename, line, SombrasNodeGetID(node), 
                                    SombrasNodeGetTitle(node));
                    SombrasNodeDestroy(node);
                    }
                }

            node = SombrasNodeNew(token);
            if(node == NULL)
                SombrasWarning("%s: line %i: Error creating node '%s'",
                            filename, line, token);

            buffer[0] = '\0';
            }



        token = SombrasGetToken(buffer, ".title");
        if(token)
            {
            SombrasStrTrim(token);
            if(node != NULL)
                SombrasNodeSetTitle(node, token);
            else
                SombrasWarning("%s: line %i: '.title' (%s) defined outside of '.node'",
                                filename, line, token);
            buffer[0] = '\0';
            }


        token = SombrasGetToken(buffer, ".desc");
        if(token)
            {
            if(node != NULL)
                {
                while(fgets(buffer, bufsize, arq) && !SombrasIsToken(buffer, ".end"))
                    {
                    line++; /* incrementar isso sempre que ler uma linha!! */ 
                    if(!SombrasIsToken(buffer, ".end"))
                        SombrasNodeAppendDesc(node, buffer);
                    }
                line++;  /* chuncho: dentro do while, a linha do .end n�o � contada */
                }
            else
                SombrasWarning("%s: line %i: '.desc' defined outside of '.node'",
                                filename, line);
            buffer[0] = '\0';
            }



        token = SombrasGetToken(buffer, ".exit");
        if(token)
            {
            SombrasStrTrim(token);
            if(node != NULL)
                {
                /* token � o id da saida, procuro qq coisa apos ele para a desc */
                tempstr = token;
                while(*tempstr != ' ' &&  *tempstr != '\t' &&  *tempstr != '\0')
                    tempstr++;
                if(*tempstr != '\0')
                    {
                    *tempstr = '\0';
                    tempstr++;
                    }
                SombrasStrTrim(tempstr);
                SombrasNodeAddExit(node, token, tempstr);
                }
            else
                SombrasWarning("%s: line %i: '.exit' (%s) defined outside of '.node'",
                                filename, line, token);
            buffer[0] = '\0';
            }



        if(SombrasIsToken(buffer, ".end"))
            {
            if(node != NULL)
                {
                if(SombrasNodeListAddNode(nodelist, node) == SOMBRAS_ERROR_NODE_ALREADY_EXISTS)
                    {
                    SombrasWarning("%s: line %i: .end: Node '%s' ('%s') already defined",
                                    filename, line, SombrasNodeGetID(node), 
                                    SombrasNodeGetTitle(node));
                    SombrasNodeDestroy(node);
                    }
                }
            else
                SombrasWarning("%s: line %i: '.end' defined outside of '.node'",
                                filename, line);
            node = NULL;
            buffer[0] = '\0';
            }
        }

    fclose(arq);
    free(buffer);

    return nodelist;
    }



/*  this is a big, dirt, and ugly function ... */

int SombrasNodeListDebug(TSombrasNodeList *nodelist)
    {
    int result = SOMBRAS_OK;
    int nodetemp;
    int exittemp;

    SombrasWarning("NodeList Debug: %i nodes defined", 
                    SombrasNodeListGetSize(nodelist));

    if(SombrasNodeListGetNode(nodelist, "begin") == NULL)
        {
        SombrasWarning("NodeList Debug: No 'begin' node defined");
        result = SOMBRAS_ERROR;
        }

    for(nodetemp=0; nodetemp<nodelist->numnodes; nodetemp++)
        {
        if((nodelist->nodes[nodetemp])->numexits == 0)
            {
            SombrasWarning("NodeList Debug: Node '%s' ('%s') has no exits",
                                    (nodelist->nodes[nodetemp])->id, 
                                    (nodelist->nodes[nodetemp])->title);
            result = SOMBRAS_ERROR;
            }
        else
            {
            for(exittemp=0; exittemp<(nodelist->nodes[nodetemp])->numexits; exittemp++)
                if(SombrasNodeListGetNode(nodelist, 
                    ((nodelist->nodes[nodetemp])->exits[exittemp])->id) == NULL 
                    && strcmp(((nodelist->nodes[nodetemp])->exits[exittemp])->id, "end"))
                    {
                    SombrasWarning("NodeList Debug: Node '%s' ('%s') has an exit to a "
                                    " not defined node '%s' ('%s')",
                                    (nodelist->nodes[nodetemp])->id, 
                                    (nodelist->nodes[nodetemp])->title,
                                    ((nodelist->nodes[nodetemp])->exits[exittemp])->id,
                                    ((nodelist->nodes[nodetemp])->exits[exittemp])->desc);

                    result = SOMBRAS_ERROR;
                    }
            }
        }

    return result;
    }




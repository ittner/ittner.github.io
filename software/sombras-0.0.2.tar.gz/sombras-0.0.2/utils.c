/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */


#include "utils.h"


void SombrasWarning(const char *fmt, ...)
    {
    va_list arg_ptr;

    va_start(arg_ptr, fmt);
    fprintf(stderr, "Sombras: Warning: ");
    vfprintf(stderr, fmt, arg_ptr);
    fprintf(stderr, "\n");
    va_end(arg_ptr);
    }






int SombrasStrTrim(char *str)
    {
    int pos;
    while(str[0] == ' '  || str[0] == '\t' ||
          str[0] == '\n' || str[0] == '\r')
        for(pos=0; pos<strlen(str); pos++)
            str[pos] = str[pos+1];

    while(str[strlen(str)-1] == ' '  || str[strlen(str)-1] == '\t' ||
          str[strlen(str)-1] == '\n' || str[strlen(str)-1] == '\r')
        str[strlen(str)-1] = 0;

    return strlen(str);
    }






/* Se str comeca com token, retona um ponteiro para o
   primeiro caracter n�o-espa�o ap�s token
   caso contr�rio retorna NULL

   O espa�o ap�s o token � substitu�do por \0, quebrando
   a string
*/
    
char *SombrasGetToken(char *str, char *token)
    {
    if(!strncmp(str, token, strlen(token)))
        {
        while(*str != ' ' && *str != '\t' && *str != '\0')
            str++;
        if(*str != '\0')
            {
            *str = '\0';
            str++;
            }
        return str;
        }

    return NULL;
    }





/* verifica se str come�a com  token, por�m
   ignora os espa�o que o precedem
*/

int SombrasIsToken(char *str, char *token)
    {
    while(*str == ' ' || *str == '\t')
        str++;

    if(strncmp(str, token, strlen(token)))
        return FALSE;
    else
        return TRUE;
    }



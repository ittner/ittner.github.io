/*
 *              S O M B R A S 
 *
 *
 *   (c) 2002 Alexandre Erwin Ittner
 *   aittner@netuno.com.br
 *   http://users.netuno.com.br/aittner/
 *
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 *
 */


#include "sombras.h"
#include "node.h"
#include "nodelist.h" 
#include "utils.h"



void SombrasPrintTitle(char *str)
    {
    int antes = COLS/2 - strlen(str)/2;
    int chars = antes + strlen(str);

    attrset(A_REVERSE);
    while(antes-- > 0)
        addstr(" ");

    addstr(str);

    while(chars++ < COLS)
        addstr(" ");

    attrset(A_NORMAL);
    addstr("\n");
    }




void SombrasSetScreen(char *title)
    {
    clear();
    move(0, 0);
    SombrasPrintTitle(title);
    }





void SombrasPrintNodeToScreen(TSombrasNode *node)
    {
    int exitnum = 0;
    char *title;
    char *desc;

    if(node == NULL)
        return;

    title = SombrasNodeGetTitle(node);
    if(title == NULL)
        return;

    desc = SombrasNodeGetDesc(node);
    if(desc == NULL)
        return;

    SombrasSetScreen(title);
    addstr("\n");
    addstr(desc);
    addstr("\n\n");

    SombrasPrintTitle("There are these ways");
    for(exitnum=1; exitnum <= SombrasNodeGetNumExits(node); exitnum++)
        printw("    %i - %s\n", exitnum, SombrasNodeGetExitDesc(node, exitnum-1));
    addstr("\n\n");
    }



        
char *SombrasRunNode(TSombrasNode *node)
    {
    char resp[10] = "";
    unsigned int exitnum = 0;

    if(node == NULL)
        return NULL;

    while(exitnum == 0 || exitnum > SombrasNodeGetNumExits(node))
        {
        SombrasPrintNodeToScreen(node);
        move(LINES-1, 0);
        addstr("You have a choice: ");
        getnstr(resp, 9);
        exitnum = atoi(resp);
        }

    return SombrasNodeGetExitID(node, exitnum-1);
    }






void SombrasRunNodeList(TSombrasNodeList *nodelist)
    {
    char *nodeid;

    initscr();
    keypad(stdscr, TRUE);
    nonl();
    cbreak();

    nodeid = SombrasRunNode(SombrasNodeListGetNode(nodelist, "begin"));
    while(nodeid != NULL)
        {
        nodeid = SombrasRunNode(SombrasNodeListGetNode(nodelist, nodeid));
        if(nodeid != NULL)
           if(strcmp(nodeid, "end") == 0)
               nodeid = NULL;
        }

    SombrasSetScreen("You back to the reality");
    refresh();

    endwin(); 
    }





void SombrasShowUsage(FILE *saida)
    {
    fprintf(saida, "Sombras version " SOMBRAS_VERSION " (" SOMBRAS_NICKNAME ")\n");
    fprintf(saida, "(c) 2002 Alexandre Erwin Ittner\n");
    fprintf(saida, "aittner@netuno.com.br - http://users.netuno.com.br/aittner/\n\n");
    fprintf(saida, "Usage: sombras [-d] filename\n");
    }



int main(int argc, char *argv[])
    {
    TSombrasNodeList *nl;

    if(argc < 2 || argc > 3)
        {
        SombrasShowUsage(stderr);
        return 1;
        }


    if(argc == 3)
        {
        if(strcmp(argv[1], "-d") == 0)
            {
            nl = SombrasNodeListNewFromFile(argv[2]);
            if(nl == NULL)
                {
                SombrasWarning("Error loading '%s'", argv[2]);
                return 1;
                }

            SombrasNodeListDebug(nl);
            SombrasNodeListDestroy(nl);
            return 0;
            }
        else
            {
            SombrasShowUsage(stderr);
            return 1;
            }
        }


    nl = SombrasNodeListNewFromFile(argv[1]);
    if(nl == NULL)
        {
        SombrasWarning("Error loading '%s'", argv[1]);
        return 1;
        }

    SombrasRunNodeList(nl);
    SombrasNodeListDestroy(nl);

    return  0;
    }

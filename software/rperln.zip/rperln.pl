#!/usr/local/bin/perl 
################################################################
#
# 
#                    R P e r l N
#
#          Copyleft (c) ALEXANDRE ERWIN ITTNER 
#                 kernel32@bigfoot.com
#               http://kernel32.cjb.net
#
#
# Este  programa � um software de livre distribui��o, que 
# pode ser copiado e distribu�do sob os termos da Licen�a 
# P�blica Geral GNU  ( GNU General Public License - GPL ) 
# vers�o  2,   conforme   publicada  pela  Free  Software 
# Foundation.  Este programa � distribu�do na expectativa 
# de  ser  �til  aos  seus usu�rios, por�m N�O H� NENHUMA 
# GARANTIA,  EXPL�CITA  OU  IMPL�CITA,  COMERCIAL  OU  DE 
# ATENDIMENTO  A UMA  DETERMINADA FINALIDADE.  Consulte a 
# Licen�a  P�blica  Geral GNU (GNU General Public License
# - GPL) para maiores detalhes. 
#
#
################################################################
# Variaveis de configuracao
################################################################
$endereco_script = "/cgi-bin/rperln.pl";

################################################################
# Programa Principal
################################################################
use CGI qw/:standard :netscape/;
$pilha = param("pilha");
$operacao = param("operacao");
$entrada = param("entrada");
@pilha = split(/_/,$pilha);
srand();
$numero_randomico = rand();
$tamanho_pilha = @pilha;


################################################################
# Implementacao das funcoes da pilha
################################################################
if ($operacao eq "enter")
	{
	push(@pilha,$entrada);
	$aviso = "OK";
	}

if ($operacao eq "clear")
	{
	@pilha = ();
	$aviso = "Pilha esvaziada";
	}

if ($operacao eq "drop")
	{
	$x = pop(@pilha);
	$aviso = "OK";
	}

if ($operacao eq "dup")
	{
	$x = pop(@pilha);
	push(@pilha,$x);
	push(@pilha,$x);
	$aviso = "OK";
	}

if ($operacao eq "swap")
	{
	if ($tamanho_pilha >= 2)
		{
		$elemento1 = pop(@pilha);
		$elemento2 = pop(@pilha);
		push(@pilha, $elemento1);
		push(@pilha, $elemento2);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "soma")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		$x = $y + $x;
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "subtracao")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		$x = $y - $x;
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "multiplicacao")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		$x = $y * $x;
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "divisao")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		unless ($x == 0)
			{
			$x = $y / $x;
			push(@pilha,$x);
			$aviso = "OK";
			}
		else
			{
			if ($y == 0)
				{
				$aviso = "ERRO: Resultado Indefinido";
				}
			else
				{
				$aviso = "ERRO: Resultado Infinito";
				}
			}
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "inverso")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		unless ($x == 0)
			{
			$x = 1 / $x;
			push(@pilha,$x);
			$aviso = "OK";
			}
		else
			{
			$aviso = "ERRO: Resultado Infinito";
			}
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "potencia")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		$x = $y ** $x;
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "raiz2")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		$x = $x ** 0.5;
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "raizx")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		$x = $y ** (1/$x);
		push(@pilha,$x);
		$aviso = "OK";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "seno")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		$x = sin($x);
		push(@pilha,$x);
		$aviso = " AVISO: Seno em RADIANOS!!";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "cosseno")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		$x = cos($x);
		push(@pilha,$x);
		$aviso = " AVISO: Cosseno em RADIANOS!!";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "tangente")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		$x = sin($x) / cos($x);
		push(@pilha,$x);
		$aviso = " AVISO: Tangente em RADIANOS!!";
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "ln")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		unless($x == 0)
			{
			$x = log($x);
			push(@pilha,$x);
			$aviso = "OK";
			}
		else
			{
			$aviso = "ERRO: Resultado Infinito";
			}
		}
	else
		{
		$aviso = "ERRO: Poucos Argmentos";
		}
	}

if ($operacao eq "log")
	{
	if ($tamanho_pilha >= 1)
		{
		$x = pop(@pilha);
		unless($x == 0)
			{
			$x =log($x)/log(10);
			push(@pilha,$x);
			$aviso = "OK";
			}
		else
			{
			$aviso = "ERRO: Resultado Infinito";
			}
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "logx")
	{
	if ($tamanho_pilha >= 2)
		{
		$x = pop(@pilha);
		$y = pop(@pilha);
		unless($y == 0)
			{
			$x =log($y)/log($x);
			push(@pilha,$x);
			$aviso = "OK";
			}
		else
			{
			$aviso = "ERRO: Resultado Infinito";
			}
		}
	else
		{
		$aviso = "ERRO: Poucos Argumentos";
		}
	}

if ($operacao eq "pi")
	{
	push(@pilha,3.14159265359);
	$aviso = "AVISO: Pseudo PI";
	}


################################################################
# Recria e formata a pilha
################################################################

$pilha = join("_",@pilha);
@pilha = reverse(@pilha);
$numero_elemento_pilha = 1;
foreach $elemento_pilha(@pilha)
	{
	$x_ou_y = "";
	if ($numero_elemento_pilha == 1) { $x_ou_y = "(x)"; }
	if ($numero_elemento_pilha == 2) { $x_ou_y = "(y)"; }
	$pilha_formatada = "$numero_elemento_pilha$x_ou_y: $elemento_pilha<br>$pilha_formatada";
	$numero_elemento_pilha++;
	}	

################################################################
# Retorna o HTML ao usuario
################################################################
$fonte = "Verdana,verdana,Helvetica,helvetica,Arial,arial";
print("Content-type: text/html


<html>
<head>
<title>Calculadora RPerlN versao 0.9</title>
</head>
<body bgcolor=#ffffff text=#000000>
<center>
<font face='$fonte' size='2'>
<img src='rperln.gif'>
</center>
<font face='$fonte' size='2'>
<p>Use esta calculadora da mesma forma que voc� usa sua calculadora RPN favorita. </p>
<table border='0' width='50%'>
  <tr>
      <td><p>Pilha Operacional</p></td>
  </tr>
  <tr bgcolor=#fffff0>
      <td><p>$pilha_formatada</p></td>
  </tr>
</table>
<br>
<table border='0' width='50%'>
  <tr>
     <td><p>Avisos/Erros</p></td>
  </tr>
  <tr bgcolor=#fffff0>
    <td><b>$aviso</b></td>
  </tr>
</table>
<br>
<table border='0'  width='50%' bgcolor=#fffff0>
  <tr>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='soma'><input type='submit' value='y+x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='potencia'><input type='submit' value='y^x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='seno'><input type='submit' value='SIN(x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='enter'><input type='text' size='7' name='entrada' value='0'><br><input type='submit' value='ENTER'></form></td>
  </tr>
  <tr>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='subtracao'><input type='submit' value='y-x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='raiz2'><input type='submit' value='y^(1/2)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='cosseno'><input type='submit' value='COS(x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='drop'><input type='submit' value='DROP'></form> </td>
  </tr>
  <tr>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='multiplicacao'><input type='submit' value='y*x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='raizx'><input type='submit' value='y^(1/x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='tangente'><input type='submit' value='TAN(x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='clear'><input type='submit' value='CLEAR'></form> </td>
  </tr>
  <tr>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='divisao'><input type='submit' value='y/x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='inverso'><input type='submit' value='1/x'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='pi'><input type='submit' value='pi'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='swap'><input type='submit' value='SWAP'></form> </td>
  </tr>
  <tr>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='logx'><input type='submit' value='log x(y)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='log'><input type='submit' value='log(x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='ln'><input type='submit' value='ln(x)'></form> </td>
     <td><form action='$endereco_script' method='POST'><input type='hidden' name='anti_cache' value='$numero_randomico'> <input type='hidden' name='pilha' value='$pilha'> <input type='hidden' name='operacao' value='dup'><input type='submit' value='DUP'></form> </td>
  </tr>
</table>
<br><br>
</font>
<center>
<hr>
<p><font face='$fonte' size='1'> RPerlN - Copyleft (c) <a href='mailto:kernel32\@bigfoot.com'>Alexandre Erwin Ittner</a> (<a href='http://kernel32.cjb.net'>http://kernel32.cjb.net</a>)
<br> Distribuido segundo GPL/GNU vers�o 2.</font></p>
</body>
</html>
");
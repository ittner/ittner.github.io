<?php

/*
 *                               mktext.php
 *               quick & dirty script to make a blended text
 *
 *                    (c) 2003 Alexandre Erwin Ittner    
 *                         aittner@netuno.com.br
 *                   http://users.netuno.com.br/aittner/ 
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 * get arguments
 *      t   :   Text
 *      s   :   Font size
 *      bg  :   Background color (triple hex RRGGBB)
 *      fg  :   Foreground color (triple hex RRGGBB)
 *
 *
 */

/* Default settings */

$fontFile = "thefont.ttf";      /* Font file name (must be in local dir)    */
$fontSize = 36;                 /* Font size (in pixels)                    */
$fontAngle = 0.0;               /* Text rotation angle                      */
$imgBorder = 2;                 /* Image borders                            */
$bgColorStr = "000000";         /* Background color                         */
$fgColorStr = "FFFFFF";         /* Foreground color                         */

/* Set this to some string to block access from other sites. This
   string will be checked with strstr(), so "ourfriends.com" will
   allow access from "www.ourfriends.com", "forum.ourfriends.com",
   etc. and deny access from "www.theenemy.com" */
$blockReferrer = "";



$text = "";
if(isset($_GET["t"]))
    $text = $_GET["t"];

if(isset($_GET["s"]))
    $fontSize = intval($_GET["s"]);

if(isset($_GET["bg"]))
    $bgColorStr = $_GET["bg"];

if(isset($_GET["fg"]))
    $fgColorStr = $_GET["fg"];

if(isset($_SERVER["HTTP_REFERER"]))
    if(strlen($_SERVER["HTTP_REFERER"]) > 0
    && strlen($blockReferrer) > 0)
        if(!strstr($_SERVER["HTTP_REFERER"], $blockReferrer))
        {
            $text = "Access Denied\n Bad referrer";
            $fontSize = 72;
            $bgColorStr = "FF0000";
            $fgColorStr = "FFFFFF";
        }


header("Content-type: image/png");

/* This function was 'stolen' from PHP Manual :) */
function ImageColorAllocateHEX($im, $s)
{
    if($s[0] == "#")
        $s = substr($s, 1);
    $bg_dec = hexdec($s);
    return ImageColorAllocate($im,
        ($bg_dec & 0xFF0000) >> 16,
        ($bg_dec & 0x00FF00) >>  8,
        ($bg_dec & 0x0000FF));
}


/* Some bizarre logic to get the size and position of the rendered text */

$bbox = ImageTTFBBox($fontSize, $fontAngle, $fontFile, $text);
$xsize = max($bbox[2], $bbox[4]) - min($bbox[0], $bbox[6]) + 2 * $imgBorder;
$ysize = max($bbox[1], $bbox[3]) - min($bbox[5], $bbox[7]) + 2 * $imgBorder;
$xpos = 0 + imgBorder;
$ypos = -min($bbox[5], $bbox[7]) + $imgBorder;


/* The function 'ImageCreateTrueColor()' requires gd 2.0. We don't know
   the version installed on system, so this logic will detect it */

if(function_exists("ImageCreateTrueColor"))
{
    $im = ImageCreateTrueColor($xsize, $ysize);
    ImageAntiAlias($im, true);
}
else 
    $im = ImageCreate($xsize, $ysize);

$bgColor = ImageColorAllocateHEX($im, $bgColorStr);
$fgColor = ImageColorAllocateHEX($im, $fgColorStr);

ImageFill($im, 0, 0, $bgColor);
ImageTTFText($im, $fontSize, $fontAngle, $xpos, $ypos, $fgColor, $fontFile, $text);
ImagePNG($im);
ImageDestroy($im);

?>

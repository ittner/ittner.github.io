#!/usr/bin/env perl

#                 ANAFF - A Not�cia Agora Feed Filter
#
#        (c) 2004 Alexandre Erwin Ittner <aittner@netuno.com.br>
#                  http://users.netuno.com.br/aittner/
#
#
#   Este programa l� as manchetes do site do  A Not�cia e as retorna
#   em um formato RDF padronizado,  para exibi��o em qualquer leitor
#   de feeds que suporte leitura a partir da sa�da de comandos, como
#   o Liferea (http://liferea.sourceforge.net).
#
#   ATEN��O:  Vale lembrar que esse script l� os dados a  partir  do
#   HTML  existente no site do  A Not�cia!  Qualquer mudan�a no site
#   provavelmente o far� parar de funcionar!
#
#
#                            LICEN�A DE USO
#
#   Este  programa � um  software  livre  que  pode  ser  copiado  e
#   distribu�do nos termos da Licen�a P�blica Geral GNU (GNU General
#   Public License - GPL) vers�o 2 da licen�a ou,  a  seu  crit�rio,
#   qualquer   vers�o  posterior.   Este   programa  foi  criado  na
#   expectativa  de  ser  �til,  por�m  N�O POSSUI NENHUMA GARANTIA,
#   EXPRESSA, IMPL�CITA  OU  DE  ATENDIMENTO  A  ALGUMA  DETERMINADA
#   FINALIDADE.  Para  maiores informa��es consulte o texto completo
#   da  Licen�a P�blica Geral  GNU  no arquivo  COPYING  distribu�do
#   juntamente com este programa.
#
#
# $Id: anaff.pl,v 1.13 2006/01/09 00:46:12 dermeister Exp $
#

my $anprefix = "http://portal.an.com.br";
my $anurl = "$anprefix/HomeAgora.jsp";
my $title = "A Not�cia";

# Offset das not�cias no site em rela��o ao UTC. Notas:
# - � *offset* e n�o *zona de fuso hor�rio*
# - N�o lida automaticamente com o hor�rio de ver�o.
my $utcoff = "-02:00";

# Revis�o do CVS. Deixe que ele cuide disso!
my $cvsid = '$Revision: 1.13 $';
my $cvsrev = "0.0";
if($cvsid =~ /\$Revision: *([0-9.]*)/i)
{
    $cvsrev = $1
}

my $dados = `wget -q -O - $anurl`;

# Deixa tudo em uma �nica linha. Isso facilitar� as coisas depois.
$dados =~ s/[\n\r\t]/ /gi;

# Imagens, scripts, fontes e coment�rios n�o nos interessam. Vamos
# retir�-los para facilitar o parsing depois.
$dados =~ s/<style[^>]*>.*?<\/style>//gi;
$dados =~ s/<script[^>]*>.*?<\/script>//gi;
$dados =~ s/<basefont [^>]*>//gi;
$dados =~ s/<\/?font>//gi;
$dados =~ s/<img[^>]*>//gi;
$dados =~ s/<\/?span.*?>//gi;
$dados =~ s/<!--.*?-->//gi;
$dados =~ s/< *br *\/?>/<br>/gi;

# Retira espa�os duplos.
$dados =~ s/&nbsp;/ /gi;
$dados =~ s/ +/ /gi;

# Tenta detectar o charset utilizado. Perigo: pode criar XML inv�lido!!
my $charset = "iso-8859-1";
if ($dados =~ /<meta [^>]*; *charset=([^"]+)"/i)
{
    $charset = $1;
}

# Agora as manchetes est�o no formato:
#
# 17:12 <a href="DetANAgora.jsp?sCodANAgora=1146&sCodEditoria=2">
# Ir� pode retomar pesquisa nuclear ainda hoje </a><br>
#
# e as datas em: 
#
# 08/01/2006 <br>
#
# <br> ser� o separador.

my @dlist = split(/<br>/i, $dados);

print <<_EOD_;
<?xml version="1.0" encoding="$charset"?>
<rdf:RDF
  xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns="http://purl.org/rss/1.0/">
 <channel rdf:about="$anurl">
  <title>$title</title>
  <link>$anurl</link>
  <description>
    Feed extra�do automaticamente do site do jornal A Not�cia pelo
    anaff.pl, vers�o $cvsrev. Lembre-se que mudan�as no site do A Not�cia
    podem fazer esse script parar de funcionar a qualquer momento. Em caso
    de qualquer problema, tente primeiro obter uma vers�o mais atualizada
    deste script em http://users.netuno.com.br/aittner/data/anaff.tar.gz
  </description>
  <dc:language>pt-br</dc:language>
  <dc:rights>Copyright A Not�cia</dc:rights>
  <dc:publisher>A Not�ia</dc:publisher>
  <dc:creator>A Not�cia</dc:creator>
  <dc:subject>News</dc:subject>
_EOD_

my $data = "0001-01-01";
my @items;
my $i = 0;
my $first = 1;
my $tmp;

# Percorre cada elemento do vetor, procurando pelas manchetes.
foreach $tmp (@dlist)
{
    if($tmp =~ /([0-9][0-9])\/([0-9][0-9])\/([0-9][0-9][0-9][0-9])/)
    {
        $data = "$3-$2-$1";
    }
    
    if($tmp =~ /([0-9][0-9]:[0-9][0-9]).*?<a href="(.*?)">(.*?)<\/a>/)
    {
        my $hora = $1;
        my $nurl = $2;
        my $ntitle = $3;
        
        $ntitle =~ s/&/&amp;/g;
        $ntitle =~ s/</&lt;/g;
        $ntitle =~ s/>/&gt;/g;
        $nurl =~ s/&/&amp;/g;

        if($first == 1)
        {
            # Para marcar a data/hora da �ltima atualiza��o.
            print
                 "  <dc:date>". $data . "T" . $hora . ":00$utcoff</dc:date>\n"
                ."  <items>\n"
                ."   <rdf:Seq>\n";
            $first = 0;
        }

        print "    <rdf:li rdf:resource=\"$anprefix/$nurl\" />\n";
        $items[$i++] = 
             " <item rdf:about=\"$anprefix/$nurl\">\n"
            ."  <title>$ntitle</title>\n"
            ."  <link>$anprefix/$nurl</link>\n"
            ."  <description>$ntitle</description>\n"
            ."  <dc:date>". $data . "T" . $hora . ":00$utcoff</dc:date>\n"
            ."  <dc:creator>ANot�cia</dc:creator>\n"
            ."  <dc:subject>Not�cias</dc:subject>\n"
            ." </item>\n";
    }
}

print <<_EOD_;
   </rdf:Seq>
  </items>
 </channel>
_EOD_

foreach $tmp (@items)
{
    print $tmp;
}

print "</rdf:RDF>\n";


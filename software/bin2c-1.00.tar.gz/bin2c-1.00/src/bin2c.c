/*
 * bin2c - Mais um programinha para ajudar a gerar seu codigo fonte
 *
 * (c) 2001 Alexandre Erwin Ittner
 * kernel32@netuno.com.br
 * http://kernel32.cjb.net
 *
 *
 * Este programa � um software de livre distribuicao que
 * pode ser copiado e distribuido nos termos da Licenca
 * Publica Geral GNU (GPL), versao 2 ou posterior.
 * Este programa � fornecido na expectativa de ser util,
 * porem SEM NENHUMA GARANTIA, EXPRESSA, IMPLICITA OU DE
 * ATENDIMENTO A ALGUMA DETERMINADA FINALIDADE.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
	{
	FILE *arq_bin;
	unsigned char dados;
	unsigned int cont;
	char *nome_arq;
	char *nome_vetor;


	if(argc != 2)
		{
		printf("ERRO: use bin2c <arquivo>\n");
		exit(-1);
		}

	nome_arq = argv[1];

	/* malloca um espaco em memoria para o nome do vetor */	
	nome_vetor = (char *) malloc(strlen(nome_arq) + 1);


	/* Limpa qualquer caracter invalido do nome do vetor */
	strcpy(nome_vetor, nome_arq);
	for(cont=0; cont <= strlen(nome_vetor)-1; cont++)
		if( !(  (('0' <= nome_vetor[cont]) && (nome_vetor[cont] <= '9')) ||
			(('A' <= nome_vetor[cont]) && (nome_vetor[cont] <= 'Z')) ||
			(('a' <= nome_vetor[cont]) && (nome_vetor[cont] <= 'z')) ))
			nome_vetor[cont] = '_';


	arq_bin = fopen(nome_arq, "rb");
	if(!arq_bin)
		{
		printf("ERRO: impossivel abrir %s para leitura!\n", nome_arq);
		exit(-1);
		}




	fseek(arq_bin, 0, SEEK_END);
	printf("/* %s - %d bytes */\n", nome_arq, ftell(arq_bin));
	fseek(arq_bin, 0, SEEK_SET);

	printf("const char %s[] = {\n", nome_vetor);
	printf("\t\t");

	cont = 0;
	while(!feof(arq_bin))
		{
		dados = fgetc(arq_bin);
		if(cont != 0)
			printf(", ");

		if(dados < 0x10)
			printf("0x0%X", dados);
		else
			printf("0x%X", dados);

		if(cont == 10)
			{
			cont = 0;
			printf(",\n\t\t");
			}
		else
			cont++;
		}

	printf("\n\t\t};\n");
	fclose(arq_bin);
	}
		

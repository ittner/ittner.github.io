<?php

/* PPage - Script para cria��o din�mica de p�ginas sem banco de dados
   (c) 2003 Alexandre Erwin Ittner  <aittner@netuno.com.br>

   Este programa � um software de livre distribui��o que pode ser copiado
   e distribu�do nos termos da Licen�a P�blica Geral GNU (GPL) vers�o
   2 da licen�a ou, a crit�rio do autor, qualquer vers�o posterior.
   Este programa � fornecido na esperan�a de ser �til, por�m, n�o possui
   NENHUMA GARANTIA

   $Id: index.php,v 1.11 2004/07/17 21:51:44 dermeister Exp $

    --- Argumentos GET ---
    <nada>         Assume ?f=index
    f=<arquivo>    Exibe <arquivo>
    a=admin        Exibe o painel de administra��o
    a=edit         Se indicado junto com f, edita o arquivo
    a=delete       Se indicado junto com f, deleta o arquivo
    a=logout       Faz o logout

*/


/* Diret�rio dos dados - deve ter permiss�o de escrita e execu��o global
   (0777). Incluir a / no fim do nome */
$pDataDir = "./data/";


/* Senha de aministra��o da p�gina em MD5. A senha padr�o � "teste"
   MUDE ISTO OU TER� PROBLEMAS!  */
$pPasswd = "698dc19d489c4e4db73e28a713eab07b"; 


/* URL deste script -- em geral PHP_SELF funcionar� bem, mas est�
   dispon�vel para situa��es especiais */
$pUrl = "index.php";


/* Estes s�o os nomes dos arquivos especiais, que ser�o colocados no
   in�cio e no final de cada p�gina e a p�gina inicial */

$pHeader = "header";
$pFooter = "footer";
$pIndex = "index";


/* Inicializa as sess�es e determina se o usu�rio est� logado */
session_start();

$pLogged = false;
if(isset($_SESSION["passwd"]))
    if($_SESSION["passwd"] == $pPasswd)
        $pLogged = true;

/* Se a sess�o estiver inativa por 15 min, elimina o login
   (isso bypassa qualquer mecanismo do php neste sentido) */
if(!$pLogged && ($_SESSION["time"] < (time() + 900)))
{
    $_SESSION["passwd"] = false;
    $_SESSION["time"] = false;
    $pLogged = false;
}
else
    $_SESSION["time"] = time();


/* Se est� enviando a senha para logar, verifica, loga e seta
   a hora da sess�o */
if(!$pLogged && isset($_POST["passwd"]))
    if(md5($_POST["passwd"]) == $pPasswd)
    {
        $_SESSION["passwd"] = md5($_POST["passwd"]);
        $_SESSION["time"] = time();
        $pLogged = true;
        pShowFile($pHeader);
        pPrintAdminPanel();
        pShowFile($pFooter);
        exit();
    }


/* Finalizando a sess�o e deslogando */
if(isset($_GET["a"]) && ($_GET["a"] == "logout"))
{
    $_SESSION["passwd"] = false;
    $_SESSION["time"] = false;
    $pLogged = false;
    header("Location: $pUrl");
}


pShowFile($pHeader);
if(isset($_POST["action"]))
{
    if($pLogged)
    {
        if($_POST["action"] == "edit")
            pApplyEdit();
        if($_POST["action"] == "delete")
            pApplyDelete();
        if($_POST["action"] == "upload")
            pApplyUpload();
    }
    else
        pPrintPasswdPanel();
}
else if(isset($_GET["a"]))
{
    if($pLogged)
    {
        if($_GET["a"] == "admin")
            pPrintAdminPanel();
        else if($_GET["a"] == "edit")
            pEditFile(pStripMagic($_GET["f"]));
        else if($_GET["a"] == "delete")
            pPrintDeleteForm(pStripMagic($_GET["f"]));
    }
    else
        pPrintPasswdPanel();
}
else if(isset($_GET["f"]))
    pShowFile(pStripMagic($_GET["f"]));
else
{
        $_GET["f"] = $pIndex;
    pShowFile($pIndex);
}

pShowFile($pFooter);



/* ------------------------------------------------------------------------ */


/* Retorna uma lista com todos os arquivos existentes em $pDataDir */
function pGetFileList()
{
    global $pDataDir;
    if(!($dp = @opendir($pDataDir)))
    {
        echo "<h1>Erro abrindo diret�rio de dados ($pDataDir)</h1>\n";
        return false;    /* Erro! */
    }
    $list = array();
    $i = 0;
    while(($file = readdir($dp)) !== false)
        if(is_file("$pDataDir$file"))
            $list[$i++] = $file;
    return $list;
}



/* Verifica se o nome de arquivo passado � um arquivo v�lido em $pDataDir
   A compara��o com a lista de arquivos impede que um visitante malicioso
   consiga acessar arquivos acima de $pDataDir. Considera um nome de
   arquivo e sua representa��o em urlencode como implicitamente iguais */
function pGetFileName($fname)
{
    $list = pGetFileList();
    for($i=0; $i < sizeof($list); $i++)
        if($fname == $list[$i] || $fname == pDecodeFileName($list[$i]))
            return $list[$i];
    return false;
}



/* Manda o arquivo desejado para o cliente, aplicando algumas substitui��es. */
function pShowFile($fname)
{
    global $pDataDir;
    global $pIndex;
    global $pUrl;
    global $pLogged;

    $arq = pGetFileName($fname);
    if($arq == false)
    {
        pError404($fname);
        return;
    }

    $getf = pStripMagic($_GET["f"]);
    if($getf == false)
        $getf = $pIndex;

    $text = implode("", @file($pDataDir . $arq));
    $text = str_replace("{PPTITLE}", pDecodeFileName($fname), $text);
    $text = str_replace("{PPFTITLE}", pDecodeFileName($getf), $text);
    $text = str_replace("{PPNAME}", $fname, $text);
    $text = str_replace("{PPFNAME}", $getf, $text);
    $text = str_replace("{PPLASTCHANGE}", pGetFileUpdateTime($fname), $text);
    $text = str_replace("{PPFLASTCHANGE}", pGetFileUpdateTime($getf), $text);

    if($pLogged)
    {
        $text = str_replace("{PPEDIT}", "[<a href=\"$pUrl?a=edit&f="
            . htmlentities($fname) . "\">Editar</a>]", $text);
        $text = str_replace("{PPFEDIT}", "[<a href=\"$pUrl?a=edit&f="
            . htmlentities($getf) . "\">Editar</a>]", $text);
        $text = str_replace("{PPLOGIN}", "[<a href=\"$pUrl?a=logout\">Logout</a>]", $text);
        $text = str_replace("{PPADMIN}", "[<a href=\"$pUrl?a=admin\">Admin</a>]", $text);
    }
    else
    {
        $text = str_replace("{PPADMIN}", "", $text);
        $text = str_replace("{PPFEDIT}", "", $text);
        $text = str_replace("{PPLOGIN}", "[<a href=\"$pUrl?a=admin\">Login</a>]", $text);
    }

    while(ereg("\{PPLINK:([^}]+)\}", $text, $regs))
    {
        $ourl = "{PPLINK:" . $regs[1] ."}";
        $nurl = "<a href=\"" . $pUrl . "?f=" . 
                htmlentities(pEncodeFileName($regs[1])) . "\">"
                . $regs[1] . "</a>";
        $text = str_replace($ourl, $nurl, $text);
    }

    while(ereg("\{PPNLINK:([^:]+):([^}]+)\}", $text, $regs))
    {
        $ourl = "{PPNLINK:" . $regs[1] . ":" . $regs[2] ."}";
        $nurl = "<a href=\"" . $pUrl . "?f=" . 
                htmlentities(pEncodeFileName($regs[1])) . "\">"
                . $regs[2] . "</a>";
        $text = str_replace($ourl, $nurl, $text);
    }

    echo $text;
}
    


/* Retorna a data da �ltima modifica��o de um arquivo em $pDataDir */
function pGetFileUpdateTime($fname)
{
    global $pDataDir;
    $arq = pGetFileName($fname);
    if($arq == false)
        return false;
    return date("d/m/Y H:i", filemtime($pDataDir . $arq));
}



function pPrintFileUpdateTime($fname)
{
    if($data = pGetFileUpdateTime($fname))
        echo "P�gina atualizada pela �ltima vez em $data";
}


function pStripMagic($str)
{
    if(get_magic_quotes_gpc() == 1)
        return stripslashes($str);
    return $str;
}


function pPrintPasswdPanel()
{
    global $pUrl;
?>
<center>
 <h1>Senha</h1>
 <form action="<?php echo $pUrl; ?>" method="POST">
  <input type="password" name="passwd" value="" size="20" /> 
  <input type="submit" name="btsub" value="OK" />
 </form>
</center>
<?php
}




function pPrintEditForm($fname, $text)
{
    global $pUrl;
?>
<center>
 <h1>Editar Arquivo</h1>
 <form action="<?php echo $pUrl; ?>" method="POST">
  <input type="hidden" name="action" value="edit" />
  Nome do Arquivo: <input type="text" name="fname" value="<?php echo $fname; ?>" size="20" /> <br>
  T�tulo da P�gina: <b> <?php echo pDecodeFileName($fname); ?> </b> <br>
  <br>
  <textarea name="text" cols="90" rows="20"><?php echo $text; ?></textarea>
  <table border="0">
   <tr>
    <td><input type="submit" name="btsub" value="Salvar" /></td>
    <td><input type="reset" name="btres" value="Desfazer" /></td>
   </tr>
  </table>
 </form>
</center>
<?php
}



function pPrintDeleteForm($fname)
{
    global $pUrl;
?>
<center>
 <h1>Excluir Arquivo</h1>
 <form action="<?php echo $pUrl; ?>" method="POST">
  <input type="hidden" name="action" value="delete" />
  <input type="text" name="fname" value="<?php echo $fname; ?>" size="20" />
  <input type="submit" name="btsub" value="Excluir" />
 </form>
</center>
<?php
}


function pError404($fname)
{
    global $pLogged;
    global $pUrl;
?>
<center>
 <h1>Erro 404</h1>
 <p>A p�gina que voc� est� tentando acessar n�o existe.</p>
 <p><a href="<?php echo $pUrl; ?>">Voltar</a></p>
<?php
    if($pLogged)
        echo " <p><a href=\"" . $pUrl . "?a=edit&f=" . htmlentities($fname) . 
            "\">Criar p�gina</a></p>\n";
?>
</center>
<?php
}


function pEditFile($fname)
{
    global $pDataDir;

    $newarq = false;
    $arq = pGetFileName($fname);
    if($arq !== false)
    {
        if(!is_writable("$pDataDir$arq"))
        {
            echo "<center><h1>Arquivo $arq � somente leitura!</h1></center>";
            pPrintAdminPanel();
            return;
        }
        $data = @file("$pDataDir$arq");
        $text = implode("", $data);
    }
    else
    {
        $arq = pEncodeFileName(trim($fname));
        $text = "Criando arquivo novo.\n";
    }
    pPrintEditForm($arq, $text);
}


function pIsValidFileName($fname)
{
    if(ereg("[~!@#^&*()=|\\/:;\$', -]+", $fname))
        return false;
    return true;
}


/* Codifica uma string com um m�todo compat�vel com urlencode,*por�m*
   codifica tamb�m qualquer caracter especial. Usado para transformar
   t�tulos de p�ginas em nomes de arquivos. */

function pEncodeFileName($fname)
{
    $nname = "";
    for($i = 0; $i < strlen($fname); $i++)
    {
        if(ereg("[a-zA-Z0-9._]", $fname[$i]))
            $nname = $nname . $fname[$i];
        else
        {   
            $hx = dechex(ord($fname[$i]));
            if(strlen($hx) == 1)
                $hx = "0" . $hx;
            $nname = $nname . "%" . $hx;
        }
    }
    return $nname;
}


/* Decodifica um nome de arquivo para o t�tulo da p�gina correspondente. */
function pDecodeFileName($fname)
{
    return urldecode($fname);
}

            
function pApplyEdit()
{
    global $pDataDir;

    $fname = pStripMagic($_POST["fname"]);
    $text = pStripMagic($_POST["text"]);

    if(!pIsValidFileName($fname))
    {
        echo "<center><h1>Nome de arquivo inv�lido</h1></center>";
        pPrinteditForm($fname, $text);
        return;
    }

    $text = trim($text);
    $text = str_replace("\r", "", $text);

    $fp = fopen("$pDataDir$fname", "w");
    if(!$fp)
    {
        echo "<center><h1>Erro ao abrir o arquivo</h1></center>";
        pPrintEditForm($fname, $text);
        return;
    }

    fputs($fp, $text);
    if(fclose($fp) == false)
    {
        echo "<center><h1>Erro ao fechar o arquivo</h1></center>";
        pPrintEditForm($fname, $text);
        return;
    }

    chmod("$pDataDir$fname", 0666);
    echo "<center><h1>Arquivo $fname salvo</h1></center>";
    pPrintAdminPanel();
    return;
}



function pApplyDelete()
{
    global $pDataDir;

    $fname = pStripMagic($_POST["fname"]);
    $arq = pGetFileName($fname);
    unlink("$pDataDir$arq");
    echo "<center><h1>Arquivo $fname exclu�do</h1></center>";
    pPrintAdminPanel();
    return;
}



function pApplyUpload()
{
    global $pDataDir;
    $tname = $_FILES[fname][tmp_name][0];
    $realname = $_FILES[fname][name][0];
    copy($tname, "$pDataDir$realname");
    chmod("$pDataDir$realname", 0666);
    echo "<center><h1>Arquivo copiado com nome $realname</h1></center>";
    pPrintAdminPanel();
    return;
}



function pPrintAdminPanel()
{
    global $pUrl;
    global $pDataDir;
    $list = pGetFileList();
?>
<hr>
<table border="0">
 <tr>
  <td> <b> Arquivo </b> </td>
  <td> <b> T�tulo </b> </td>
  <td> <b> Tamanho </b> </td>
  <td> <b> Editar </b> </td>
  <td> <b> Excluir </b> </td>
  <td> <b> Download </b> </td>
 </tr>
<?php
    sort($list, SORT_STRING);
    foreach($list as $tmp)
    {
        echo "<tr> ";
        echo "<td> <a href=\"$pUrl?f=$tmp\">$tmp</a> </td> ";
        echo "<td> " . htmlentities(pDecodeFileName($tmp)) . " </td> ";
        echo "<td> " . sprintf("%.2fkB", (filesize("$pDataDir$tmp")/1024.0)) . " </td> ";
        echo "<td> [<a href=\"$pUrl?f=" . urlencode($tmp) . "&a=edit\">Editar</a>] </td> ";
        echo "<td> [<a href=\"$pUrl?f=" . urlencode($tmp) . "&a=delete\">Excluir</a>] </td> ";
        echo "<td> [<a href=\"$pDataDir" . urlencode($tmp) . "\">Download</a>] </td> ";
        echo "</tr>\n";
    }
?>
</table>
<hr>
<b>Novo arquivo:</b>
<form action="<?php echo $pUrl; ?>" method="GET">
 <input type="hidden" name="a" value="edit" />
 <input type="text" name="f" size="20" />
 <input type="submit" value="Criar" />
</form>
<hr>

<b>Upload de arquivo:</b>
<form enctype="multipart/form-data" action="<?php echo $pUrl; ?>" method="POST">
 <input type="hidden" name="action" value="upload" />
 <input type="hidden" name="MAX_FILE_SIZE" value="3000000" />
 Arquivo: <input type="file" name="fname[]" size="20" />
 <input type="submit" name="btsub" value="Enviar" />
</form>
<?php
    echo "<hr>\n";
    echo "[<a href=\"$pUrl?a=logout\">Logout</a>]\n";
}



?>

#!/usr/bin/perl

#
# mkthumbs (c) 2002 Alexandre Erwin Ittner
# aittner@netuno.com.br
# http://users.netuno.com.br/aittner/
#
# Distributed under GNU GPL - WITHOUT ANY WARRANTY
#
# This script requires ImageMagic instaled in your system
#


$thumb_prefix = "thumb_";
$html_prefix = "image_";
$thumb_size = "80x80";




$result = `rm -f $thumb_prefix* $html_prefix*.html`;
@all_files = `ls *.jpg *.gif *.png | sort`;

$cont = 1;
foreach $arq_atual (@all_files)
    {
    $arq_atual =~ s/\n//g;
    print "Convertendo $arq_atual -> $thumb_prefix$arq_atual\n";

    $result = `convert -geometry $thumb_size "$arq_atual" "$thumb_prefix$arq_atual"`;
    open(Arq, ">$html_prefix$cont.html");
    print Arq "<html>\n";
    print Arq "<head>\n";
    print Arq " <title>$arq_atual</title>\n";
    print Arq "</head>\n";
    print Arq "<body>\n";
    print Arq " <center>\n";
    print Arq "  &lt;&lt; <a href=\"$html_prefix\index.html\">Voltar</a>\n";
    print Arq "  <br><br>\n";
    print Arq "  <img src=\"$arq_atual\">\n";
    print Arq "  <br><br>\n";
    print Arq "  &lt;&lt; <a href=\"$html_prefix\index.html\">Voltar</a>\n";
    print Arq " </center>\n";
    print Arq "</body>\n";
    print Arq "</html>\n";
    close(Arq);
    $cont++;
    }


open(Arq, ">$html_prefix\index.html");
print Arq "<html>\n";
print Arq "<head>\n";
print Arq " <title>Imagens</title>\n";
print Arq "</head>\n";
print Arq "<body>\n";
print Arq " <center>\n";
print Arq "  <table boder=0>\n";
print Arq "   <tr>\n";

$cont = 1;
$colunas = 0;

foreach $arq_atual (@all_files)
    {
    $arq_atual =~ s/\n//g;
    print Arq "    <td>\n";
    print Arq "     <center>\n";
    print Arq "      <a href=\"$html_prefix$cont.html\">\n";
    print Arq "       <img src=\"$thumb_prefix$arq_atual\">\n";
    print Arq "      </a>\n";
    print Arq "     </center>\n";
    print Arq "    </td>\n";
    $cont++;

    if($colunas == 4)
        {
        print Arq "   </tr>\n";
        print Arq "   <tr>\n";
        $colunas = 0;
        }
    else
        {
        $colunas++;
        }
    }


print Arq "   </tr>\n";
print Arq "  </table>\n";
print Arq "  $cont Imagens nesta galeria\n";
print Arq " </center>\n";
print Arq "</body>\n";
print Arq "</html>\n";
close(Arq);








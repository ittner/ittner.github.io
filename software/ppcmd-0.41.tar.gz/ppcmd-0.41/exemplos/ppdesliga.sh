#/bin/bash

#
# Desliga o sistema ao 1 minuto apos receber 1 pulso.
# Cancela o desligamento imediatamente apos receber 2 pulsos
#

ppcmd    "clear; echo DESLIGANDO O SISTEMA EM 1 min; shutdown -h 1" \
	 "shutdown -c DESLIGAMENTO CANCELADO!!" 




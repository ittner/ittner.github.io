#!/bin/bash

# Usa o mpg123 para tocar seus mp3, continos na
# lista indicada pos $minha_lista.
# 1 pulso inicia a reproducao 
# 2 pulsos param
#


#indique sua lista aqui
minha_lista=~/lista;


ppcmd 	"mpg123 -@$minha_lista -Z &"	\
	"killall mpg123"				


/*
 * ppcmd (aka ParPort CoMmanDer) 
 *  (c) Alexandre Erwin Ittner 2000-01
 *   kernel32@users.sourceforge.net
 *   kernel32@bigfoot.com
 *   http://kernel32.cjb.net
 *
 *
 *
 *
 * Este programa e' um software de livre distribuicao que
 * pode ser copiado e distribuido nos termos da Licenca
 * Publica Geral GNU (GPL), versao 2, ou posterior.
 * Este programa e' distribuido SEM NENHUMA GARANTIA, 
 * EXPRESSA, IMPLICITA OU DE ATENTIMENTO A UMA DETERMINADA
 * FINALIDADE. Consulte a GPL para maiores detalhes.
 *
 * Veja o arquivo 'doc/ppcmd.html' para detalhes do circuito. 
 * 
 *
 * Este programa foi feito e testado exclusivamente em um linux
 * 2.2.xx com glibc 2.1.1. A principio roda em qualquer *nix-i386
 * Me avise se voce confirmar isto.
 *
 * -------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * See the file 'doc/ppcmd.html' for circuitry details.
 *
 *
 * This program was made and ran in a linux 2.2.xx with glibc 2.1.1,
 * if you run it in another *nix, please mail-me.
 *
 */
 

/* AJUSTE ESTAS DEFINICOES ANTES DE COMPILAR!!	*/
/* SET THESE DEFINITIONS BEFORE COMPILE!!	*/


#define porta_dados  0x378		/* Definicao dos enderecos da porta de dados 	*/
					/* Data port address definition 		*/

#define porta_status 0x379		/* Definicao dos enderecos da porta de status 	*/
					/* Status port address definition 		*/

#define tempo_limite 2			/* Tempo para executar um comando, apos seleciona-lo */
					/* Delay for run a command, after select it 	*/

#define tempo_espera 10			/* Define o delay padrao - em ms 		*/
					/* Default delay definition - in miliseconds 	*/

#define usar_beeps 1			/* Emite um beep quando um comando for 
					   selecionado e 2 quando for cancelado 	*/
					/* Use beeps when receiving a command 		*/

/* #define exibir_msg_erro_beeps 1 */	/* Exibe uma mensagem de erro quando
					   tentar sair o beep para dev_dsp
					   e o mesmo estiver ocupado 			*/
					/* Show fault messages, on device
					   access error 				*/

#define dev_dsp "/dev/dsp"		/* Dispositivo da sua placa de som 		*/
					/* Your soundcard device 			*/

#define num_caract_env 200		/* Numero de bytes enviados para dev_dsp
					   a cada beep 					*/
					/* The lenght of sound signal 			*/






#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/io.h>
#include <time.h>




#ifdef usar_beeps
void toca_beep()
	{
        int  temp = 0;
        FILE *arq_dsp;
        
        arq_dsp = fopen(dev_dsp, "w");
        if(arq_dsp)
               {
               for(temp=0; temp<=num_caract_env; temp++)
                 	{
                        fputc(255, arq_dsp);
                        fputc(0, arq_dsp);
			fflush(arq_dsp);  /* hora da limpeza... */
                        }
           
               fflush(arq_dsp);
               fclose(arq_dsp); 
               }

	#ifdef exibir_msg_erro_beeps
        else
               printf("ppcmd: ERRO: %s indisponivel!\n", dev_dsp);
	#endif
        }
#endif



int main(int argc, char *argv[])
	{
	unsigned char estado_atual = 0;
	unsigned char estado_anterior = 0;
	unsigned int num_comandos = 0;
	unsigned int cmd_selec = 0;
	int temp = 0;
	int cmd_prep = 0;
	long tatual = 0;
	long tinicio = 0;
	unsigned int tempo_espera_us = 1000*tempo_espera;	



	printf("ppcmd 0.41 - (c) Alexandre Erwin Ittner 2000-01\n");
	printf("Distribuido segundo GPL 2 - SEM NENHUMA GARANTIA\n");
	printf("Intervalo de E/S: %xh - %xh\n", porta_dados, porta_status);
	printf("Delay: %dms - Frequencia de Scan: %dHz\n", tempo_espera, (int)(1000/tempo_espera));

	#ifdef usar_beeps
		printf("\nCompilado com suporte a beeps em %s\n", dev_dsp);

		#ifndef exibir_msg_erro_beeps
		printf("Ignorando mensagens de erro do dispositivo %s!\n", dev_dsp);
		#endif
	#endif
        printf("\n");

	if (argc < 2)
		{
		printf("Use:\n");
		printf("ppcmd \"comando1 -x --opcao 1\" \"comando2 -y --opcao 2\" ... \n\n");
		printf("lembre-se de colocar comandos interativos em segundo plano\n");
		printf("caso contrario, ppcmd sera interrompido!!\n");
		exit(-1);
		}

	num_comandos = argc - 1;

	printf("%d comandos definidos:\n", num_comandos);
	for(temp=1; temp<=num_comandos; temp++)
		printf("    %d: '%s'\n", temp, argv[temp]);

	printf("\nCTRL+C para finalizar...\n\n");

        estado_atual = 255;  /*	evita a selecao do 1o. 	comando quando
				o programa inicia */

	while(1)
		{
		if (!iopl(3))   /* Poder total e absoluto, nivel 3 */ 
			{ 
			outb(porta_dados, 128);  /* seta o bit 7 */
			usleep(1);
			estado_anterior = estado_atual;
			estado_atual = inb(porta_status);
			outb(porta_dados, 0);
			iopl(0);

			if(cmd_prep != 0)
				{
				tatual = time(0);
				if(difftime(tatual, tinicio) > tempo_limite)
					{
					printf("ppcmd: executando comando %d (%s)\n", cmd_selec, argv[cmd_selec]);
					system(argv[cmd_selec]);

					cmd_selec=0;
					cmd_prep=0;
					}
				}

			if(estado_anterior < estado_atual)   /* borda de subida */
				{
				tinicio = time(0);
				cmd_prep = 1;
				cmd_selec++;

				#ifdef usar_beeps
                                toca_beep();
				#endif

				if(cmd_selec <= num_comandos)
					printf("ppcmd: comando %d selecionado (%s), executando em %ds\n", 
						cmd_selec, argv[cmd_selec], tempo_limite);
				else
					{
					cmd_selec=0;
					cmd_prep=0;

					#ifdef usar_beeps
					/* 2 beeps seguidos: esse eh o 2o */
					toca_beep();
					#endif

					printf("ppcmd: comando cancelado\n");
					}

				usleep(tempo_espera_us); 
						/* espera um pouco mais antes de aceitar
						outro comando, evita que o repique do  contato
						da chave seja interpretado como uma nova selecao
						*/
				}
			usleep(tempo_espera_us);
			}
		else
			{
			printf("ERRO: Permissao de acesso a porta negada!\n");
			exit(-1);
			}
		}
	}



#!/usr/local/bin/perl 
#########################################################
#
# 
#            V  C  M  E  S  M  O   1 . 0 
#
#          Copyleft (c) ALEXANDRE ERWIN ITTNER 
#                kernel32@bigfoot.com
#               http://kernel32.cjb.net
#
#
# Este  programa � um software de livre distribui��o, que 
# pode ser copiado e distribu�do sob os termos da Licen�a 
# P�blica Geral GNU  ( GNU General Public License - GPL ) 
# vers�o  2,   conforme   publicada  pela  Free  Software 
# Foundation.  Este programa � distribu�do na expectativa 
# de  ser  �til  aos  seus usu�rios, por�m N�O H� NENHUMA 
# GARANTIA,  EXPL�CITA  OU  IMPL�CITA,  COMERCIAL  OU  DE 
# ATENDIMENTO  A UMA  DETERMINADA FINALIDADE.  Consulte a 
# Licen�a  P�blica  Geral GNU (GNU General Public License
# - GPL) para maiores detalhes. 
#
#
#########################################################
#         Variaveis de configuracao
#########################################################
$arquivo_contador = "acessos.txt";

#########################################################
#         Codigo principal
#########################################################
open(arq_contador,"$arquivo_contador");
$acessos = <arq_contador>;
close(arq_contador);
$acessos++;
open(arq_contador,">$arquivo_contador");
print arq_contador $acessos;
close(arq_contador);
$nome_usuario = $ENV{'USER_NAME'}; #Quase impossivel, mas...
unless($nome_usuario eq "")
	{
	$nome_usuario = "$nome_usuario <font color='red'> CUIDADO! melhor rever sua pol�tica de privacidade </font>";
	}
else
	{
	$nome_usuario = "(Nome n�o encontrado, voc� n�o tem problemas mentais :-)";
	}
$ip_visitante = $ENV{'REMOTE_ADDR'};
$navegador_visitante = $ENV{'HTTP_USER_AGENT'};
if ($navegador_visitante eq "")
	{
	$navegador_visitante = "[Desconhecido]";
	}
($p1,$p2,$p3,$p4) = split(/\./,$ip_visitante,4);
$ip_provedor = "$p1.$p2.$p3.1";
$host_visitante = `nslookup $ip_visitante`;
if ($host_visitante eq "") 
	{
	$host_visitante = "<font color='red'> [Falha ao efetuar nslookup] </font>";
	}
$host_provedor = `nslookup $ip_provedor`;
if ($host_provedor eq "")
	{
	$host_provedor = "<font color='red'> [Falha ao efetuar nslookup] </font>";
	}
$ping_visitante = `ping -c 5 $ip_visitante`; 
if ($ping_visitante eq "")
	{
	$ping_visitante = "<font color='red'> [Falha ao efetuar ping] </font>";
	}
$ping_provedor = `ping -c 5 $ip_provedor`;
if ($ping_provedor eq "")
	{
	$ping_provedor = "<font color='red'> [Falha ao efetuar ping] </font>";
	}
$trace_visitante = `traceroute $ip_visitante`;
if ($trace_visitante eq "")
	{
	$trace_visitante = "<font color='red'> [Falha ao efetuar traceroute] </font>"; 
	}
$host_visitante =~ s/\n/ - /;
$host_provedor =~ s/\n/ - /;
$ping_visitante =~ s/\n/<br>/g;
$ping_provedor =~ s/\n/<br>/g;
$trace_visitante =~ s/\n/<br>/g;

print ("Content-type: text/html\n\n
	<HTML>
	<HEAD>
	<TITLE>VCMESMO</TITLE>
	</HEAD>
	<BODY bgcolor=#ffffff text=#000000>
	<font face='Verdana,Verdana,Helvetica,helvetica,Arial,arial' size='2'>
	<center>
	<img src='vcmesmo_logo.jpg'>
	</center>
	<p> Veja o que seu IP e seus HTTP-headers est�o falando de <b>voc�</b>. Estas informa��es podem ser obtidas por qualquer site da Web</p>
	<p><b> Seu nome: $nome_usuario</b> 
	<br><font size='1'> (isso funcionava nos tempos do Mosaic, atualmente s� se obt�m de usu�rios MUITO incautos. Mesmo assim, � poss�vel determinar facilmente o nome de algu�m, sabendo seu IP e entrando em contato com seu provedor. Principalmente certos provedores brasileiros que em geral n�o se preocupam nem um pouco com a privacidade de seus assinantes e fornecem dados pessoais dos mesmos a qualquer um.) </font><br>
	<br><b> Seu Navegador: $navegador_visitante </b>
	<br><font size='1'> (esta informa��o � obtida por muitos sites para reformatar as p�gina de acordo com o navegador, n�o � necessariamente uma viola��o de privacidade) </font><br>
	<br><b> Seu endere�o IP: $ip_visitante </b>
	<br><font size='1'> (cuidado, isso tem pego muito lammer por a�... e qualquer site obtem. Mesmo que voc� esteja usando um proxy, quem garante que ele n�o tenha logado seu verdadeiro IP?)</font><br>
	<br><b> Endere�o IP do seu provedor: $ip_provedor </b>
	<br><font size='1'> (� na base do chut�metro, colocando 1 no low level domain do seu IP. Lembre-se o script pode n�o encontr�-lo, mas qualquer webmaster ou sysop consegue!) </font><br>
	<br><b> Seu hostname: $host_visitante </b> 
	<br><font size='1'> (usando os servidores DNS para determinar o hostname assossiado a $ip_visitante, se houver) </font><br>
	<br><b> Hostname do seu provedor: $host_provedor </b>
	<br><font size='1'> (usando os servidores DNS para determinar o hostname assossiado ao IP 'chutado' do seu provedor) </font><br>
	</p>
	<p><b> Resultado do Ping no seu IP ($ip_visitante) </b><br>
	<hr align='left' width='50%'>
	<font size='1'>$ping_visitante</font></p>
	<hr align='left' width='50%'><br>
	<p><b> Resultado do Ping no IP do seu provedor ($ip_provedor). </b><br>
	<hr align='left' width='50%'>
	<font size='1'>$ping_provedor</font></p>
	<hr align='left' width='50%'><br>
	<p><b> E, para finalizar, tracerouter no seu IP. </b><br>
	<hr align='left' width='50%'>
	<font size='1'>$trace_visitante</font></p>
	<hr align='left' width='50%'><br>
	<p> Viu? Voc� n�o est� t�o an�nimo quanto parece.</p>
	<br>
	<center>
	<font size='1'>
	<hr>
	<p>VCMESMO - Criado por <a href='mailto:kernel32\@bigfoot.com'>Alexandre Erwin Ittner</a> (<a href='http://www.netuno.com.br/~aittner/'>www.netuno.com.br/~aittner/</a>). Distribuido segundo GPL/GNU vers�o 2
	<br>Este servi�o foi utilizado por <font color='red'>$acessos</font> usu�rios
	<br><br>Este � um servi�o p�blico e gratuito. Resolvi coloc�-lo no ar porque muitos usu�rios n�o est�o cientes de que <b>nada</b> � an�nimo na Internet, n�o mantenho nenhum registro espec�fico dos visitantes. </p>
	</font>
	</center>
	</BODY>
	</HTML>
	");

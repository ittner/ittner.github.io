#!/usr/bin/env perl

#
#                    PHORUMFF - Phorum Feed Filter
#
#        (c) 2004 Alexandre Erwin Ittner <aittner@netuno.com.br>
#                  http://users.netuno.com.br/aittner/
#
#
#   Este programa l� os t�picos de qualquer f�rum baseado no  Phorum
#   e os  retorna em um formato  RDF  padronizado,  para exibi��o em
#   qualquer  leitor de  feeds que suporte leitura a partir da sa�da
#   de comandos.
#
#   ATEN��O:  Vale lembrar que esse script l� os dados a  partir  do
#   HTML existente no f�rum!  Qualquer mudan�a no site provavelmente
#   o far� parar de funcionar!
#
#
#                            LICEN�A DE USO
#
#   Este  programa � um  software  livre  que  pode  ser  copiado  e
#   distribu�do nos termos da Licen�a P�blica Geral GNU (GNU General
#   Public License - GPL) vers�o 2 da licen�a ou,  a  seu  crit�rio,
#   qualquer   vers�o  posterior.   Este   programa  foi  criado  na
#   expectativa  de  ser  �til,  por�m  N�O POSSUI NENHUMA GARANTIA,
#   EXPRESSA, IMPL�CITA  OU  DE  ATENDIMENTO  A  ALGUMA  DETERMINADA
#   FINALIDADE.  Para  maiores informa��es consulte o texto completo
#   da  Licen�a P�blica Geral  GNU  no arquivo  COPYING  distribu�do
#   juntamente com este programa.
#
#
# $Id: phorumff.pl,v 1.5 2004/09/14 23:38:39 dermeister Exp $
#

if($#ARGV != 1)
{
    print "Usage: phorumff.pl <url> <n�mero>\n";
    exit(1);
}

# Revis�o do CVS. Deixe que ele cuide disso!
my $cvsid = '$Revision: 1.5 $';
my $cvsrev = "0.0";
if($cvsid =~ /\$Revision: *([0-9.]*)/i)
{
    $cvsrev = $1
}

my $urlbase = @ARGV[0];
my $number = @ARGV[1];
my $urllist = "$urlbase/list.php?p=$number";

my $dados = `wget -q -O - $urllist`;
$dados =~ s/\n/ /gi;
$dados =~ s/\t/ /g;

$dados =~ s/<style[^>]*>[^<]*<\/style>//gi;
$dados =~ s/<(base)?font [^>]*>//gi;
$dados =~ s/<\/font>//gi;
$dados =~ s/<img[^>]*>//gi;
$dados =~ s/<!--[^<>]*-->//gi;

$dados =~ s/<table *[^>]*>/<table>/gi;
$dados =~ s/<th *[^>]*>/<th>/gi;
$dados =~ s/<tr *[^>]*>/<tr>/gi;
$dados =~ s/<td *[^>]*>/<td>/gi;
$dados =~ s/<span[^>]*>/<span>/gi;
$dados =~ s/<div[^>]*>/<div>/gi;

$dados =~ s/&nbsp;/ /gi;
while($dados =~ /  /)
{
    $dados =~ s/  / /g;
}

$dados =~ s/> *</></gi;
$dados =~ s/< */</gi;
$dados =~ s/ *>/>/gi;

# Obt�m o t�tulo da p�gina.
my $title = "Sem t�tulo";
if ($dados =~ /<title>([^>]+)<\/title>/i)
{
    $title = $1;
}

my @mlist = split(/<tr><td><table><tr><td><\/td>/, $dados);

print "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
print "<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n";
print "	 xmlns=\"http://my.netscape.com/rdf/simple/0.9/\">\n";
print " <channel>\n";
print "  <title>Phorum - $title</title>\n";
print "  <link>$urllist</link>\n";
print "  <description>";
print " Feed extra�do automaticamente do $title pelo phorumff.pl vers�o";
print " $cvsrev\. Lembre-se que mudan�as no f�rum podem fazer esse script";
print " parar de funcionar a qualquer momento. Em caso de qualquer problema,";
print " tente primeiro obter uma vers�o mais atualizada deste script em";
print " http://users.netuno.com.br/aittner/data/phorumff.tar.gz\n";
print "  </description>\n";
print " </channel>\n";

my $i = 0;
while($i < $#mlist)
{
    my $tmp = @mlist[$i];
    
    # Retira tags in�teis.
    $tmp =~ s/<\/tr><\/table><\/td>//gi;
    $tmp =~ s/<\/tr>//gi;
    $tmp =~ s/&/&amp;/gi;
    
    #<td><a href="read.php?xxx">ASSUNTO</a> novo</td><td>AUTOR</td><td>09-11-04 23:45 </td>

#    print "$tmp\n";
    if($tmp =~ /<td> *<a *href="([^"]+)" *>([^<]+)<\/a>[^<]+<\/td><td>([^<]+)<\/td><td>([^<]+)<\/td>/i)
    {
        print " <item>\n";
        print "  <title>$4 - $2 ($3)</title>\n";
        print "  <link>$urlbase/$1</link>\n";
        print "  <description>$4 - $2 ($3)</description>\n";
        print " </item>\n";
    }
    $i += 1;
}

print "</rdf:RDF>\n";


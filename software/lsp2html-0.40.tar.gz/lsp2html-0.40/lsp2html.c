/*
 * lsp2html
 * (c) 2001 Alexandre Erwin Ittner
 * aittner@netuno.com.br
 * http://users.netuno.com.br/aittner/
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *

 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>


#define DEFAULT_DEF_FILE   ".lsp2html.conf"

#ifndef DEBUG
#define VERSAO  "0.40-0"
#else
#define VERSAO  "0.40-0 DEBUG"
#endif




#define DEFAULT_BODY_COLOR          "white"
#define DEFAULT_CODE_COLOR          "black"
#define DEFAULT_STRING_COLOR        "red"
#define DEFAULT_COMMENT_COLOR       "green"
#define DEFAULT_ESCAPE_COLOR        "purple"
#define DEFAULT_PARENTHESES_COLOR   "gray"
#define DEFAULT_LINE_NUMBER_COLOR   "navy"
#define DEFAULT_TITLE               "Untitled"
#define DEFAULT_AUTHOR              ""
#define DEFAULT_KEYWORDS            "lisp lsp2html"
#define DEFAULT_CODE_SIZE           "+0"
#define DEFAULT_PARENTHESES_SIZE    "+0"
#define DEFAULT_BOLD_PARENTHESES    1
#define DEFAULT_ITALICT_COMMENTS    0
#define DEFAULT_SHOW_TITLE          0
#define DEFAULT_SHOW_TIMESTAMP      1
#define DEFAULT_SHOW_LINE_NUMBERS   0
#define DEFAULT_SPACES_PER_TAB      4

#define CONF_MAX_LINHA         4096
#define TAMANHO_CAMPO_STRING   128
#define TAMANHO_CAMPO_COR      16
#define TAMANHO_CAMPO_FONTE    16





void warning(const char *fmt, ...);
int strtrim(char *str);
long StreamCopy(FILE *dest, FILE *src);
void Timestamp(FILE *arq);
void MostraAjuda(void);
void RestauraDefaults(void);
int CarregaDefinicoes(char *nomearq);
void ImprimeDefinicoes(FILE *fp);
void SetFontTag(FILE *dest, char *cor, char *tam);
int converte_lsp2html(char *nomeArqOrig);
int main(int argc, char *argv[]);




struct 
        {
        char BodyColor[TAMANHO_CAMPO_COR];
        char CodeColor[TAMANHO_CAMPO_COR];
        char StringColor[TAMANHO_CAMPO_COR];
        char CommentColor[TAMANHO_CAMPO_COR];
        char EscapeColor[TAMANHO_CAMPO_COR];
        char ParenthesesColor[TAMANHO_CAMPO_COR];
        char LineNumberColor[TAMANHO_CAMPO_COR];
        char CodeSize[TAMANHO_CAMPO_FONTE];
        char ParenthesesSize[TAMANHO_CAMPO_FONTE];
        char Title[TAMANHO_CAMPO_STRING];
        char Author[TAMANHO_CAMPO_STRING];
        char Keywords[TAMANHO_CAMPO_STRING];
        char Header[TAMANHO_CAMPO_STRING];
        char Footer[TAMANHO_CAMPO_STRING];
        int  BoldParentheses;
        int  ItalictComments;
        int  ShowTitle;
        int  ShowTimestamp;
        int  ShowLineNumbers;
        int  SpacesPerTab;
        } Definicoes;






/* from gnu libc manual */
void warning(const char *fmt, ...)
    {
    va_list arg_ptr;

    va_start(arg_ptr, fmt);
    fprintf(stderr, "lsp2html: ");
    vfprintf(stderr, fmt, arg_ptr);
    fprintf(stderr, "\n");
    va_end(arg_ptr);
    }






int strtrim(char *str)
    {
    int pos;
    while(str[0] == ' '  || str[0] == '\t' ||
          str[0] == '\n' || str[0] == '\r')
        for(pos=0; pos<strlen(str); pos++)
            str[pos] = str[pos+1];

    while(str[strlen(str)-1] == ' '  || str[strlen(str)-1] == '\t' ||
          str[strlen(str)-1] == '\n' || str[strlen(str)-1] == '\r')
        str[strlen(str)-1] = 0;

    return strlen(str);
    }






long StreamCopy(FILE *dest, FILE *src)
    {
    char buf[4096]; 
    long cont = 0;
    long total = 0;

    while(!feof(src))
        {
        cont = fread(buf, 1, 4096, src);
        fwrite(buf, 1, cont, dest);
        total += cont;
        }

    return total;
    }







void Timestamp(FILE *arq)
    {
    time_t DataUnix;
    struct tm *DataHora;

    time(&DataUnix);
    DataHora = localtime(&DataUnix);

    fprintf(arq, "%s%d/%s%d/%d %s%d:%s%d:%s%d",
            (DataHora->tm_mday < 10) ? "0" : "", DataHora->tm_mday,
            ((DataHora->tm_mon+1) < 10) ? "0" : "", DataHora->tm_mon+1,
            DataHora->tm_year + 1900,
            (DataHora->tm_hour < 10) ? "0" : "", DataHora->tm_hour,
            (DataHora->tm_min < 10) ? "0" : "", DataHora->tm_min,
            (DataHora->tm_sec < 10) ? "0" : "", DataHora->tm_sec);
    }
  






void MostraAjuda(void)
    {
    fprintf(stderr,
            "lsp2html " VERSAO " (c) 2001 Alexandre Erwin Ittner \n"
            "aittner@netuno.com.br - http://users.netuno.com.br/aittner/ \n"
            "Distributed under GNU GPL - WITHOUT ANY WARRANTY! \n\n"
            "Usage: lsp2html [-d definition_file] lsp_file [...] \n"
            " (arguments will be evaluated from left to right) \n");
    }






void RestauraDefaults(void)
    {
#ifdef DEBUG
    warning("debug: setting up default definitions");
#endif 

    strncpy(Definicoes.Header, "", TAMANHO_CAMPO_STRING);
    strncpy(Definicoes.Footer, "", TAMANHO_CAMPO_STRING);
    strncpy(Definicoes.Title, DEFAULT_TITLE, TAMANHO_CAMPO_STRING);
    strncpy(Definicoes.Author, DEFAULT_AUTHOR, TAMANHO_CAMPO_STRING);
    strncpy(Definicoes.Keywords, DEFAULT_KEYWORDS, TAMANHO_CAMPO_STRING);
    strncpy(Definicoes.CodeSize, DEFAULT_CODE_SIZE, TAMANHO_CAMPO_FONTE);
    strncpy(Definicoes.ParenthesesSize, DEFAULT_PARENTHESES_SIZE, TAMANHO_CAMPO_FONTE);
    strncpy(Definicoes.BodyColor, DEFAULT_BODY_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.CodeColor, DEFAULT_CODE_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.StringColor, DEFAULT_STRING_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.CommentColor, DEFAULT_COMMENT_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.EscapeColor, DEFAULT_ESCAPE_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.ParenthesesColor, DEFAULT_PARENTHESES_COLOR, TAMANHO_CAMPO_COR);
    strncpy(Definicoes.LineNumberColor, DEFAULT_LINE_NUMBER_COLOR, TAMANHO_CAMPO_COR);
    Definicoes.BoldParentheses = DEFAULT_BOLD_PARENTHESES;
    Definicoes.ItalictComments = DEFAULT_ITALICT_COMMENTS;
    Definicoes.ShowTitle = DEFAULT_SHOW_TITLE;
    Definicoes.ShowTimestamp = DEFAULT_SHOW_TIMESTAMP;
    Definicoes.ShowLineNumbers = DEFAULT_SHOW_LINE_NUMBERS;
    Definicoes.SpacesPerTab = DEFAULT_SPACES_PER_TAB;
    }





int CarregaDefinicoes(char *nomearq)
    {
    FILE *Arq;
    char linha[CONF_MAX_LINHA];
    char *valor;
    int temp;

    RestauraDefaults();
#ifdef DEBUG
    warning("debug: loading definitions from %s", nomearq);
#endif 

    Arq = fopen(nomearq, "rt");
    if(!Arq)
        return 0;

    while(!feof(Arq))
        {
        fgets(linha, CONF_MAX_LINHA, Arq);
        if(!feof(Arq))
            {
            for(temp=0; temp<strlen(linha); temp++)
                switch(linha[temp])
                    {
                    case '\t':
                        linha[temp] = ' ';
                        break;

                    case ';':
                    case '\n':
                        linha[temp] = 0;
                        break;
                    }
            strtrim(linha);
            valor = &linha[0];
            while(*valor != ' ' && *valor != '\0')
                valor++;

            if(*valor != '\0')
                {
                *valor = '\0';
                valor++;
                strtrim(valor);

                if(!strcmp(linha, "header"))
                    strncpy(Definicoes.Header, valor, TAMANHO_CAMPO_STRING);

                if(!strcmp(linha, "footer"))
                    strncpy(Definicoes.Footer, valor, TAMANHO_CAMPO_STRING);

                if(!strcmp(linha, "title"))
                    strncpy(Definicoes.Title, valor, TAMANHO_CAMPO_STRING);

                if(!strcmp(linha, "author"))
                    strncpy(Definicoes.Author, valor, TAMANHO_CAMPO_STRING);

                if(!strcmp(linha, "keywords"))
                    strncpy(Definicoes.Keywords, valor, TAMANHO_CAMPO_STRING);

                if(!strcmp(linha, "body_color"))
                    strncpy(Definicoes.BodyColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "code_color"))
                    strncpy(Definicoes.CodeColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "string_color"))
                    strncpy(Definicoes.StringColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "comment_color"))
                    strncpy(Definicoes.CommentColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "escape_color"))
                    strncpy(Definicoes.EscapeColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "parentheses_color"))
                    strncpy(Definicoes.ParenthesesColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "line_number_color"))
                    strncpy(Definicoes.LineNumberColor, valor, TAMANHO_CAMPO_COR);

                if(!strcmp(linha, "code_size"))
                    strncpy(Definicoes.CodeSize, valor, TAMANHO_CAMPO_FONTE);

                if(!strcmp(linha, "parentheses_size"))
                    strncpy(Definicoes.ParenthesesSize, valor, TAMANHO_CAMPO_FONTE);

                if(!strcmp(linha, "bold_parentheses"))
                    Definicoes.BoldParentheses = atoi(valor);

                if(!strcmp(linha, "italict_comments"))
                    Definicoes.ItalictComments = atoi(valor);

                if(!strcmp(linha, "show_title"))
                    Definicoes.ShowTitle = atoi(valor);

                if(!strcmp(linha, "show_timestamp"))
                    Definicoes.ShowTimestamp = atoi(valor);

                if(!strcmp(linha, "show_line_numbers"))
                    Definicoes.ShowLineNumbers = atoi(valor);

                if(!strcmp(linha, "spaces_per_tab"))
                    Definicoes.SpacesPerTab = atoi(valor);
                }
            }
        }
    fclose(Arq);

#ifdef DEBUG
    warning("debug: I read this:");
    ImprimeDefinicoes(stderr);
#endif
    return 1;
    }






void ImprimeDefinicoes(FILE *fp)
    {
    fprintf(fp, ";lsp2html definitions\n");
    fprintf(fp, ";field name       value\n\n");
    fprintf(fp, "header             %s\n", Definicoes.Header);
    fprintf(fp, "footer             %s\n", Definicoes.Footer);
    fprintf(fp, "title              %s\n", Definicoes.Title);
    fprintf(fp, "author             %s\n", Definicoes.Author);
    fprintf(fp, "keywords           %s\n", Definicoes.Keywords);
    fprintf(fp, "body_color         %s\n", Definicoes.BodyColor);
    fprintf(fp, "code_color         %s\n", Definicoes.CodeColor);
    fprintf(fp, "string_color       %s\n", Definicoes.StringColor);
    fprintf(fp, "comment_color      %s\n", Definicoes.CommentColor);
    fprintf(fp, "escape_color       %s\n", Definicoes.EscapeColor);
    fprintf(fp, "parentheses_color  %s\n", Definicoes.ParenthesesColor);
    fprintf(fp, "line_number_color  %s\n", Definicoes.ParenthesesColor);
    fprintf(fp, "code_size          %s\n", Definicoes.CodeSize);
    fprintf(fp, "parentheses_size   %s\n", Definicoes.ParenthesesSize);
    fprintf(fp, "bold_parentheses   %i\n", Definicoes.BoldParentheses);
    fprintf(fp, "italict_comments   %i\n", Definicoes.ItalictComments);
    fprintf(fp, "show_title         %i\n", Definicoes.ShowTitle);
    fprintf(fp, "show_line_numbers  %i\n", Definicoes.ShowLineNumbers);
    fprintf(fp, "show_timestamp     %i\n", Definicoes.ShowTimestamp);
    fprintf(fp, "spaces_per_tab     %i\n", Definicoes.SpacesPerTab);
    }







void SetFontTag(FILE *dest, char *cor, char *tam)
    {
    fprintf(dest, "</font><font color=\"%s\" size=\"%s\">", cor, tam);
    }






int converte_lsp2html(char *nomeArqOrig)
    {
    char *nomeArqDest;
    FILE *arqOrig;
    FILE *arqDest;
    FILE *arqTemp;
    int isComentario = 0;
    int isString = 0;
    int temp = 0;
    char char_at;
    int linha_num = 1;

#ifdef DEBUG
    warning("debug: processing '%s'", nomeArqOrig);
#endif 

    arqOrig = fopen(nomeArqOrig, "rt");
    if(!arqOrig)
        {
        warning("error: could not open %s for input", nomeArqOrig);
        return 0;
        }

    nomeArqDest = (char *) malloc((strlen(nomeArqOrig)+6)*sizeof(char));
    strcpy(nomeArqDest, nomeArqOrig);
    strcat(nomeArqDest, ".html");

    arqDest = fopen(nomeArqDest, "wt");
    if(!arqDest)
        {
        fclose(arqOrig);
        warning("error: could not open '%s' for output", nomeArqDest);
        return 0;
        }

    fprintf(arqDest, 
        "<!--\n"
        "  lsp2html " VERSAO " (c) 2001 Alexandre Erwin Ittner\n"
        "  aittner@netuno.com.br - http://users.netuno.com.br/aittner/\n"
        "-->\n\n\n"
        "<!--\n");

    ImprimeDefinicoes(arqDest);

    fprintf(arqDest, 
        "-->\n\n\n"
        "<html>\n"
        "<head>\n"
        " <meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\n"
        " <meta name=\"generator\" content=\"lsp2html " VERSAO "\">\n"
        " <meta name=\"author\" content=\"%s\">\n"
        " <title>%s - %s</title>\n"
        "</head>\n\n", Definicoes.Author, Definicoes.Title, nomeArqOrig);

    fprintf(arqDest, "<body bgcolor=\"%s\" text=\"%s\">\n",
            Definicoes.BodyColor, Definicoes.CodeColor);

    if(Definicoes.ShowTitle)
        fprintf(arqDest, "<center><h1>%s</h1></center>\n", Definicoes.Title);

    if(strlen(Definicoes.Header) > 0)
        {
        arqTemp = fopen(Definicoes.Header, "rt");
        if(arqTemp != NULL)
            {
            fprintf(arqDest, "\n\n\n<!-- begin of header file: %s -->\n", Definicoes.Header);
            StreamCopy(arqDest, arqTemp);
            fprintf(arqDest, "\n<!-- end of header file: %s -->\n", Definicoes.Header);
            fclose(arqTemp);
            }
        else
            warning("warning: Could not open '%s' for input", Definicoes.Header);
        }

    char_at = ' ';
    isString = 0;
    isComentario = 0;

    fprintf(arqDest, 
        "\n\n\n<!-- begin of machine generated html -->\n\n"
        "<pre>\n"
        "<font>");

    if(Definicoes.ShowLineNumbers)
        {
        SetFontTag(arqDest, Definicoes.LineNumberColor, Definicoes.CodeSize);
        fprintf(arqDest, "%6d: ", linha_num++);
        SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);
        }

    while(!feof(arqOrig))
        {
        char_at = getc(arqOrig);
        if(!feof(arqOrig))
            switch(char_at)
                {
                case '\"':
                    if(!isComentario)
                       if(isString)
                            {
                            fprintf(arqDest, "\"");
                            SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);
                            isString = 0;
                            }
                        else
                            {
                            SetFontTag(arqDest, Definicoes.StringColor, Definicoes.CodeSize);
                            fprintf(arqDest, "\"");
                            isString = 1;
                            }
                    else
                        fprintf(arqDest, "\"");
                    break;

                case '\\':
                    if(isString)
                        {
                        char_at = getc(arqOrig);
                        SetFontTag(arqDest, Definicoes.EscapeColor, Definicoes.CodeSize);
                        fprintf(arqDest, "\\%c", char_at);
                        SetFontTag(arqDest, Definicoes.StringColor, Definicoes.CodeSize);
                        }
                    break;

                case ';':
                    if(!isComentario && !isString)
                        {
                        SetFontTag(arqDest, Definicoes.CommentColor, Definicoes.CodeSize);
                        if(Definicoes.ItalictComments != 0)
                            fprintf(arqDest, "<em>");
                        fprintf(arqDest, ";");
                        isComentario = 1;
                        }
                    break;


                case '\t':
                    if(Definicoes.SpacesPerTab > 0)
                        for(temp = 0; temp < Definicoes.SpacesPerTab; temp++)
                            fprintf(arqDest, " ");
                    else
                        fprintf(arqDest, "\t");
                    break;


                case '\n':
                    if(isComentario)
                        {
                        if(Definicoes.ItalictComments)
                            fprintf(arqDest, "</em>");
                        SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);
                        isComentario = 0;
                        }
                    fprintf(arqDest, "\n");
                    if(Definicoes.ShowLineNumbers)
                        {
                        SetFontTag(arqDest, Definicoes.LineNumberColor, Definicoes.CodeSize);
                        fprintf(arqDest, "%6d: ", linha_num++);
                        if(isString)
                            SetFontTag(arqDest, Definicoes.StringColor, Definicoes.CodeSize);
                        else
                            SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);
                        }
                    break;                    

                case '(':
                    if(!isComentario && !isString)
                        {
                        SetFontTag(arqDest, Definicoes.ParenthesesColor, Definicoes.ParenthesesSize);                        
                        if(Definicoes.BoldParentheses != 0)
                            fprintf(arqDest, "<b>(</b>");
                        else
                            fprintf(arqDest, "(");
                        SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);                        
                        }
                    else
                        fprintf(arqDest, "(");
                    break;

                case ')':
                    if(!isComentario && !isString)
                        {
                        SetFontTag(arqDest, Definicoes.ParenthesesColor, Definicoes.ParenthesesSize);                        
                        if(Definicoes.BoldParentheses)
                            fprintf(arqDest, "<b>)</b>");
                        else
                            fprintf(arqDest, ")");
                        SetFontTag(arqDest, Definicoes.CodeColor, Definicoes.CodeSize);                        
                        }
                    else
                        fprintf(arqDest, ")");
                    break;

                case '<':
                    fprintf(arqDest, "&lt;");
                    break;

                case '>':
                    fprintf(arqDest, "&gt;");
                    break;

                default:
                    fprintf(arqDest, "%c", char_at);
                    break;
                }
        }
    fprintf(arqDest, 
            "</font>\n</pre>\n\n"
            "<!-- end of machine generated html -->\n\n\n" );

    if(strlen(Definicoes.Footer) > 0)
        {
        arqTemp = fopen(Definicoes.Footer, "rt");
        if(arqTemp)
            {
            fprintf(arqDest, "\n\n\n<!-- begin of footer file: %s -->\\nn", Definicoes.Footer);
            StreamCopy(arqDest, arqTemp);
            fprintf(arqDest, "\n\n<!-- end of footer file: %s -->\n\n\n", Definicoes.Footer);
            fclose(arqTemp);
            }
        else
            warning("warning: Could not open '%s' for input", Definicoes.Footer);
        }

    if(Definicoes.ShowTimestamp)
        {
        fprintf(arqDest, "\n\n<br><br>\n<hr noshade>\n");
        Timestamp(arqDest);
        fprintf(arqDest, ", %s", nomeArqOrig);
        if(strlen(Definicoes.Author) > 0)
            fprintf(arqDest, ", %s", Definicoes.Author);
        fprintf(arqDest, "\n\n");
        }

    fprintf(arqDest, "</body>\n");
    fprintf(arqDest, "</html>\n");

    fclose(arqDest);
    fclose(arqOrig);
    return 0;
    }







int main(int argc, char *argv[])
    {
    int arg_at = 0;
#ifdef GNU_UNIX
    char *homedir;
    char *def_file;
#endif


    if(argc < 2)
        {
        MostraAjuda();
        return 1;
        }

    RestauraDefaults();

#ifdef GNU_UNIX
    homedir = getenv("HOME");
    if(homedir)
        {
        def_file = (char *) malloc((strlen(homedir)+strlen(DEFAULT_DEF_FILE)+3)*sizeof(char));

        strcpy(def_file, homedir);
        strcat(def_file, "/");
        strcat(def_file, DEFAULT_DEF_FILE);

        if(CarregaDefinicoes(def_file) == 0)
            warning("Could not load user definitions from '%s'", def_file);

        free(def_file);
        }
    else
       warning("HOME environment variable not defined. "
               "Could not load user definitions.");
#endif

    for(arg_at=1; arg_at<argc; arg_at++)
        {
        if(!strcmp(argv[arg_at], "-d"))
            {
            if(arg_at < argc-1)
                {
                arg_at++;
                CarregaDefinicoes(argv[arg_at]);
                }
            else
                warning("No definition file specified for %i argument", arg_at);
            }
        else
            converte_lsp2html(argv[arg_at]);
        }

    return 0;
    }



